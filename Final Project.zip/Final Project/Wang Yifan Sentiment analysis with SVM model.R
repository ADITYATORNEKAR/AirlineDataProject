dev.off() # Clear the graph window
cat('\014') # Clear the console
rm(list=ls()) # Clear all user objects from the environment!!!
# Set working directory 
# Change to the folder containing your homework data files
setwd("C:/Users/����/Desktop/R����")
library(RCurl)
library(bitops)
library(tidyverse)
library(tm)
library(wordcloud)
library(Matrix)
library(dplyr)
# Read the Json file from my workind directory
dataset <- jsonlite::fromJSON(file('fall2019finaldata.json'))
df <- data.frame(dataset)
View(df)
FinalProject <- summary(df)
FinalProject
FinalProject2 <- str(df)
FinalProject2
#import positive and negative directory
pos <- "positiveword.txt"
neg <- "negativeword.txt"
p <- scan(pos,character(0), sep = "\n")
n <- scan(neg,character(0), sep = "\n")
p <- p[-1:-34]
n <- p[-1:-34]

#This model is analyze the entire customers with likelyhood less than 7 to see what caused this issue. And compare
#with the previous sentiment amalysis to determine our insights.
like1 <- df %>% 
  filter(df$Likelihood.to.recommend < 7)
like2 <- like1$freeText[!is.na(like1$freeText)]
word.vec4 <- VectorSource(like2)
words.corpus4 <- Corpus(word.vec4)
words.corpus4 <- tm_map(words.corpus4, stripWhitespace)
words.corpus4 <- tm_map(words.corpus4,content_transformer(tolower))
words.corpus4 <- tm_map(words.corpus4,removePunctuation)
words.corpus4 <- tm_map(words.corpus4,removeNumbers)
words.corpus4 <- tm_map(words.corpus4,removeWords,stopwords("english"))
words.corpus4 <- tm_map(words.corpus4, stemDocument)
Cloud4 <- wordcloud(words.corpus4, scale=c(5,0.5), max.words=50, random.order=FALSE, rot.per=0.35, use.r.layout=FALSE, colors=brewer.pal(8, "Dark2"))
tdm4 <- TermDocumentMatrix(words.corpus4)
m4 <- as.matrix(tdm4)
wordCounts4 <- rowSums(m4)
wordCounts4 <- sort(wordCounts4,decreasing = TRUE)
totalWords4 <- sum(wordCounts4)
words4 <- names(wordCounts4)
matchedP4 <- match(words4,p,nomatch = 0)
mCounts4 <- wordCounts4[which(matchedP4 !=0)]
mwords4 <- names(mCounts4)
npos4 <- sum(mCounts4)
npos4
matchedN4 <- match(words4,n,nomatch = 0)
nCounts4 <- wordCounts4[which(matchedN4 !=0)]
nNeg4 <- sum(nCounts4)
nNeg4
totalWords4 <- length(words4)
Posratios4 <- npos4/totalWords4
Negratios4 <- nNeg4/totalWords4
Posratios4
Negratios4

head(wordCounts4,10)

#create a subset of cheapseats
cheaps <- df %>%
  filter(df$Partner.Name =="Cheapseats Airlines Inc.")
cheaps1 <- cheaps$freeText[!is.na(cheaps$freeText)]
View(cheaps1)
#Create the word clouds for cheapseats airlines inc
word.vec1 <- VectorSource(cheaps1)
words.corpus1 <- Corpus(word.vec1)
words.corpus1 <- tm_map(words.corpus1, stripWhitespace)
words.corpus1 <- tm_map(words.corpus1,content_transformer(tolower))
words.corpus1 <- tm_map(words.corpus1,removePunctuation)
words.corpus1 <- tm_map(words.corpus1,removeNumbers)
words.corpus1 <- tm_map(words.corpus1,removeWords,stopwords("english"))
words.corpus1 <- tm_map(words.corpus1, stemDocument)
Cloud1 <- wordcloud(words.corpus1, scale=c(5,0.5), max.words=50, random.order=FALSE, rot.per=0.35, use.r.layout=FALSE, colors=brewer.pal(8, "Dark2"))
tdm1 <- TermDocumentMatrix(words.corpus1)
m1 <- as.matrix(tdm1)
wordCounts1 <- rowSums(m1)
wordCounts1 <- sort(wordCounts1,decreasing = TRUE)
#Sentiment analysis for cheapseats airlines inc.
totalWords1 <- sum(wordCounts1)
words1 <- names(wordCounts1)
matchedP1 <- match(words1,p,nomatch = 0)
mCounts <- wordCounts1[which(matchedP1 !=0)]
mwords <- names(mCounts)
npos <- sum(mCounts)
npos
matchedN1 <- match(words1,n,nomatch = 0)
nCounts <- wordCounts1[which(matchedN1 !=0)]
nNeg <- sum(nCounts)
nNeg
totalWords1 <- length(words1)
Posratios <- npos/totalWords1
Negratios <- nNeg/totalWords1
Posratios
Negratios
#Given this,we can see that Cheapseats airlines Inc.'s review was made up of about 12% positive and 
#a little less than 12% negative words.

#create a subset of oursin
oursin <- df %>%
  filter(df$Partner.Name =="Oursin Airlines Inc.")
oursin1 <- oursin$freeText[!is.na(oursin$freeText)]
#Create a wordcloud of Oursin airlines inc.
word.vec2 <- VectorSource(oursin1)
words.corpus2 <- Corpus(word.vec2)
words.corpus2 <- tm_map(words.corpus2, stripWhitespace)
words.corpus2 <- tm_map(words.corpus2,content_transformer(tolower))
words.corpus2 <- tm_map(words.corpus2,removePunctuation)
words.corpus2 <- tm_map(words.corpus2,removeNumbers)
words.corpus2 <- tm_map(words.corpus2,removeWords,stopwords("english"))
words.corpus2 <- tm_map(words.corpus2, stemDocument)
Cloud2 <- wordcloud(words.corpus2, scale=c(5,0.5), max.words=50, random.order=FALSE, rot.per=0.35, use.r.layout=FALSE, colors=brewer.pal(8, "Dark2"))
tdm2 <- TermDocumentMatrix(words.corpus2)
m2 <- as.matrix(tdm2)
wordCounts2 <- rowSums(m2)
wordCounts2 <- sort(wordCounts2,decreasing = TRUE)
#Create a sentiment analysis for Oursin Airlines Inc.
totalWords2 <- sum(wordCounts2)
words2 <- names(wordCounts2)
matchedP2 <- match(words2,p,nomatch = 0)
mCounts2 <- wordCounts2[which(matchedP2 !=0)]
mwords2 <- names(mCounts2)
npos2 <- sum(mCounts2)
npos2
matchedN2 <- match(words2,n,nomatch = 0)
nCounts2 <- wordCounts2[which(matchedN2 !=0)]
nNeg2 <- sum(nCounts2)
nNeg2
totalWords2 <- length(words2)
Posratios2 <- npos2/totalWords2
Negratios2 <- nNeg2/totalWords2
Posratios2
Negratios2
#By given this, we can see that the Oursin Airlines Inc. customers' reviews were made up of about 22% positive and 22% negative
#words.

#create a subset of flyfast
flyfast <- df %>%
  filter(df$Partner.Name == "FlyFast Airways Inc.")
flyfast1 <- flyfast$freeText[!is.na(flyfast$freeText)]
##Create the word clouds for FlyFast Airways Inc.
word.vec3 <- VectorSource(flyfast1)
words.corpus3 <- Corpus(word.vec3)
words.corpus3 <- tm_map(words.corpus3, stripWhitespace)
words.corpus3 <- tm_map(words.corpus3,content_transformer(tolower))
words.corpus3 <- tm_map(words.corpus3,removePunctuation)
words.corpus3 <- tm_map(words.corpus3,removeNumbers)
words.corpus3 <- tm_map(words.corpus3,removeWords,stopwords("english"))
words.corpus3 <- tm_map(words.corpus3, stemDocument)
Cloud3 <- wordcloud(words.corpus3, scale=c(5,0.5), max.words=50, random.order=FALSE, rot.per=0.35, use.r.layout=FALSE, colors=brewer.pal(8, "Dark2"))
tdm3 <- TermDocumentMatrix(words.corpus3)
m3 <- as.matrix(tdm3)
wordCounts3 <- rowSums(m3)
wordCounts3 <- sort(wordCounts3,decreasing = TRUE)
#Sentiment analysis for cheapseats airlines inc.
totalWords3 <- sum(wordCounts3)
words3 <- names(wordCounts3)
matchedP3 <- match(words3,p,nomatch = 0)
mCounts3 <- wordCounts3[which(matchedP3 !=0)]
mwords3 <- names(mCounts3)
npos3 <- sum(mCounts3)
npos3
matchedN3 <- match(words3,n,nomatch = 0)
nCounts3 <- wordCounts3[which(matchedN3 !=0)]
nNeg3 <- sum(nCounts3)
nNeg3
totalWords3 <- length(words3)
Posratios3 <- npos/totalWords3
Negratios3 <- nNeg/totalWords3
Posratios3
Negratios3
#By given this, we can see that the FlyFast Airways Inc.. customers' reviews were made up of about 16% positive and a little less than 16% negative
#words.

#support vector machine for CheapSeats
library(arules)
library(arulesViz)
#Contingency table to show the relationship between gender and price sensitivity
CT1 <-table(cheaps$Gender,cheaps$Price.Sensitivity)
CT1 <-prop.table(CT1)
CT1
#Visulization of the contingency table
ggpp <- data.frame(CT1)
colnames(ggpp) <- c("Gender","PriceSensitivity","Proportion")
GGP1 <- ggplot(ggpp,aes(x=ggpp$Gender, y=ggpp$Proportion,group =1))
GGP1 <- GGP1+geom_col()
GGP1 <- GGP1+theme(axis.text.x = element_text(angle = 90,hjust = 1))
GGP1 <- GGP1 + ggtitle("Contingency Table of Price Sensitivity")
GGP1
#Contingency table to show the relationship between gender and airline status
GS1 <-table(cheaps$Gender,cheaps$Airline.Status)
GS1 <- prop.table(GS1)
GS1
#create a subset that contains the attributes for creating the SVM
CheapsX <- cheaps[,3:14]
CheapsX <- select(CheapsX,-c(5,6,9,10,11))
#After I tried serval times, I found I need to use as.character to convert the data type in order to transactions
CheapsX$Airline.Status <- as.character(CheapsX$Airline.Status)
CheapsX$Gender <-as.character(CheapsX$Gender)
CheapsX$Age <- as.character(CheapsX$Age)
CheapsX$Price.Sensitivity <- as.character(CheapsX$Price.Sensitivity)
CheapsX$Loyalty <- CheapsX$Loyalty
CheapsX$Type.of.Travel <- CheapsX$Type.of.Travel
CheapsX$Class <- CheapsX$Class
martix1 <- as(CheapsX,"transactions")
itemFrequency(martix1)
ruleset <- apriori(martix1, 
                   parameter=list(support=0.005,confidence=0.5),
                   appearance = list(default="lhs", rhs=("Gender=Female")))
summary(ruleset)
inspect(ruleset)
plot(ruleset)
goodrules <- ruleset[quality(ruleset)$lift > 1.6]
inspect(goodrules)

#Create the assicoation rules for Oursin Aielines Inc.
#Create the contingency table between gender and price sensitivity
OCT1 <- table(oursin$Gender,oursin$Price.Sensitivity)
OCT2 <- prop.table(OCT1)
OCT2
#Create the contingency table between gender and Airline Status
OGS1 <-table(oursin$Gender,oursin$Airline.Status)
OGS2 <- prop.table(OGS1)
OGS2
#Subset of the attributes that should be concluded in the model
OursinX <- oursin[,3:14]
OursinX <- select(OursinX,-c(5,6,9,10,11))
#Convert data type into transactions
OursinX$Airline.Status <- as.character(OursinX$Airline.Status)
OursinX$Age <- as.character(OursinX$Age)
OursinX$Gender <- as.character(OursinX$Gender)
OursinX$Price.Sensitivity <- as.character(OursinX$Price.Sensitivity)
OursinX$Loyalty <- as.character(OursinX$Loyalty)
OursinX$Type.of.Travel <- as.character(OursinX$Type.of.Travel)
OursinX$Class <- as.character(OursinX$Class)
#Sparse matrix of the Oursin Airline Inc.
matrix2 <- as(OursinX,"transactions")
itemFrequency(matrix2)
ruleset2 <- apriori(matrix2, 
                   parameter=list(support=0.005,confidence=0.5),
                   appearance = list(default="lhs", rhs=("Gender=Female")))
summary(ruleset2)
inspect(ruleset2)
plot(ruleset2)
goodrules2 <- ruleset2[quality(ruleset2)$lift > 1.6]
inspect(goodrules2)

#Create assication rules for FlyFast Airways Inc.
#Create the contingency table between gender and price sensitivity
FFCT1 <- table(flyfast$Gender,flyfast$Price.Sensitivity)
FFCT2 <- prop.table(FFCT1)
FFCT2
#Create the contingency table between gender and Airline Status
FGS1 <-table(flyfast$Gender,flyfast$Airline.Status)
FGS2 <- prop.table(FGS1)
FGS2
#Subset of the attributes that should be concluded in the model
FlyfastX <- flyfast[,3:14]
FlyfastX <- select(FlyfastX,-c(5,6,9,10,11))
#Convert data type into transactions
FlyfastX$Airline.Status <- as.character(FlyfastX$Airline.Status)
FlyfastX$Age <- as.character(FlyfastX$Age)
FlyfastX$Gender <- as.character(FlyfastX$Gender)
FlyfastX$Price.Sensitivity <- as.character(FlyfastX$Price.Sensitivity)
FlyfastX$Loyalty <- as.character(FlyfastX$Loyalty)
FlyfastX$Type.of.Travel <- as.character(FlyfastX$Type.of.Travel)
FlyfastX$Class <- as.character(FlyfastX$Class)
#Sparse matrix of the Oursin Airline Inc.
matrix3 <- as(FlyfastX,"transactions")
itemFrequency(matrix3)
#Creates an assoication rules based on 7 variables
ruleset3 <- apriori(matrix3, 
                    parameter=list(support=0.005,confidence=0.5),
                    appearance = list(default="lhs", rhs=("Gender=Female")))
summary(ruleset3)
inspect(ruleset3)
plot(ruleset3)
goodrules3 <- ruleset3[quality(ruleset3)$lift > 1.4]
inspect(goodrules3)
#the study on female passengers shows that the most popular groups the partners should pay more attentions and provide
# better services to elders because they have lower price sensitivity and most of them purchased the ECO clasas tickets.

#Overall, we recommand that those three partners should provide more professional training to their emplooyee, especially for 
#the cabin crews and luggind services. Once they enhanced these parts, it may improve their reputations and make more profits.

#Morrover, based on the contingencu table, as we can seen, the female passengers are less price sensitity, so we strongly recommand
#these three partners developing more events that will attract more female passengers.For instances, they can provide baby seats, baby foods(adequate water for babies�� bottles on board), and baby bassinet
#services for international travelers. For domestic travelers, they can placed free diapers in the washrooms on board.
