################################################
# IST 687, Standard Homework Heading
#
# Student name: Rehman Sheikh
# Homework number: 
# Date due:
#
# Attribution statement: (choose the statements that are true)
# 1. I did this work by myself, with help from the book and the professor
#
#Library 
library(tidyverse)
library(RCurl)
library(jsonlite)
library(readxl)
library(ggplot2)
library(kernlab)
library(tm)
library(arules)
library(arulesViz)
library(gghighlight)
# Load the data
dataset <- fromJSON("fall2019-survey-M02.JSON")
df <- dataset
# View(df)

# import excel data
#df1 <- read_excel("projectData1.xlsx")
#warnings()
# seperating partners into own dataset

northWest <- df[df$Partner.Name == 'Northwest Business Airlines Inc.',]
cheapSeats <- df[df$Partner.Name == 'Cheapseats Airlines Inc.',]
flyFast <- dfm[dfm$Partner.Name == 'FlyFast Airways Inc.',]
southEast <- df[df$Partner.Name == 'Southeast Airlines Co.',]
sigmaAir <- df[df$Partner.Name == 'Sigma Airlines Inc.',]
paulSmith <- df[df$Partner.Name == 'Paul Smith Airlines Inc.',]
enjoyFlying <- df[df$Partner.Name == 'EnjoyFlying Air Services',]
oursinAir <- df[df$Partner.Name == 'Oursin Airlines Inc.',]
flyHere <- df[df$Partner.Name == 'FlyHere Airways',]
flyToSun <- df[df$Partner.Name == 'FlyToSun Airlines Inc.',]
coolAndYoung <- df[df$Partner.Name == 'Cool&Young Airlines Inc.',]
goingNorth <- df[df$Partner.Name == 'GoingNorth Airlines Inc.',]
onlyJets <- df[df$Partner.Name == 'OnlyJets Airlines Inc.',]
westAirways <- df[df$Partner.Name == 'West Airways Inc.',]

#mean of the likliehood to reccommend
mean(df$Likelihood.to.recommend, na.rm = TRUE)
# 7.17
mean(northWest$Likelihood.to.recommend, na.rm = TRUE)
# 7.42
mean(cheapSeats$Likelihood.to.recommend, na.rm = TRUE)
# 7.00
mean(flyFast$Likelihood.to.recommend, na.rm = TRUE)
# 6.45
mean(southEast$Likelihood.to.recommend, na.rm = TRUE)
# 7.26
mean(sigmaAir$Likelihood.to.recommend, na.rm = TRUE)
# 7.45
mean(paulSmith$Likelihood.to.recommend, na.rm = TRUE)
# 7.33
mean(enjoyFlying$Likelihood.to.recommend, na.rm = TRUE)
# 7.36
mean(oursinAir$Likelihood.to.recommend, na.rm = TRUE)
# 7.13
mean(flyHere$Likelihood.to.recommend, na.rm = TRUE)
# 7.58
mean(flyToSun$Likelihood.to.recommend, na.rm = TRUE)
# 7.35
mean(coolAndYoung$Likelihood.to.recommend, na.rm = TRUE)
# 7.36
mean(goingNorth$Likelihood.to.recommend, na.rm = TRUE)
# 7.29
mean(onlyJets$Likelihood.to.recommend, na.rm = TRUE)
# 7.31
mean(westAirways$Likelihood.to.recommend, na.rm = TRUE)
# 8

# Table with only likelihood to recommend of all partners
LTR <- data.frame("Partner_Name" = c("northWest","cheapSeats", "flyFast", "southEast", "sigmaAir", "paulSmith", "enjoyFlying", "oursinAir", "flyHere", 
                             "flyToSun", "coolAndYoung", "goingNorth", "onlyJets", "westAirways"), "NPS" = c(7.42, 7.00, 6.45, 7.26, 
                                                                                                             7.45, 7.33, 7.36, 7.13, 7.58, 
                                                                                                             7.35, 7.36, 7.29, 7.31, 8.00
))

# Create a graph
LTRplot <- ggplot(data = LTR, aes(x=Partner_Name, y=NPS)) + geom_bar(stat = "identity", fill = "#FF6666") + theme(axis.text.x=element_text(angle=75, hjust=1)) + gghighlight(NPS < 7.17)+ geom_hline(yintercept = 7.17, size = 2) +ylim(0,10)
LTRplot <- LTRplot+ ggtitle("NPS Average of Partners VS. Southeast Airlines Average") +theme(plot.title = element_text(hjust = 0.5))

LTRplot

# Sent analysis
charVector <- scan(df$freeText, character(0), sep = "\n")

# Read in the positive-words.txt file using the scan() function, and then removing the header info
posWords <- scan("positive-words.txt", character(0), sep = "\n")
posWords <- posWords[-1:-34]

# Read in the negative-words.txt file using the scan() function, and then removing the header info
negWords <- scan("negative-words.txt", character(0), sep = "\n")
negWords <- negWords[-1:-34]

# 

colSums(is.na(df))

canFlight<-subset(df,Flight.cancelled=="Yes")
mean(canFlight$Likelihood.to.recommend, na.rm = TRUE)
# 6.39

# Getting data ready for prediction
dfx <- df
dfx$Likelihood.to.recommend[is.na(dfx$Likelihood.to.recommend)]<-mean(dfx$Likelihood.to.recommend,na.rm=TRUE)
dfx$Likelihood.to.recommend<-as.numeric(dfx$Likelihood.to.recommend)
dfx$Likelihood.to.recommend[dfx$Likelihood.to.recommend<7] <- 0 
dfx$Likelihood.to.recommend[dfx$Likelihood.to.recommend>=7] <- 1 
dfx$Likelihood.to.recommend<-as.factor(dfx$Likelihood.to.recommend)
dfx$Likelihood.to.recommend<-as.numeric(dfx$Likelihood.to.recommend)

# LTR - good- 1, bad = 0
# munging
dfx$Departure.Delay.in.Minutes[is.na(dfx$Departure.Delay.in.Minutes)]<-round(mean(dfx$Departure.Delay.in.Minutes,na.rm=TRUE))
dfx$Arrival.Delay.in.Minutes[is.na(dfx$Arrival.Delay.in.Minutes)]<-round(mean(dfx$Arrival.Delay.in.Minutes,na.rm=TRUE))
dfx$Flight.time.in.minutes[is.na(dfx$Flight.time.in.minutes)]<-round(mean(dfx$Flight.time.in.minutes,na.rm=TRUE))

# Linear modeling
lm1<-lm(Likelihood.to.recommend~Age+Airline.Status+Gender+Price.Sensitivity+Year.of.First.Flight+Flights.Per.Year
        +Loyalty+Type.of.Travel+Total.Freq.Flyer.Accts+Shopping.Amount.at.Airport
        +Eating.and.Drinking.at.Airport+Class+Day.of.Month+Flight.date+Origin.State+Origin.City+Destination.City+Destination.State
        +Scheduled.Departure.Hour+Departure.Delay.in.Minutes+Arrival.Delay.in.Minutes+Flight.cancelled+Flight.time.in.minutes+Flight.Distance
        ,data=dfx)

summary(lm1)

lm2<-lm(Likelihood.to.recommend~Age+Airline.Status+Gender+Price.Sensitivity+Year.of.First.Flight+Flights.Per.Year
        +Loyalty+Type.of.Travel+Total.Freq.Flyer.Accts+Shopping.Amount.at.Airport
        +Eating.and.Drinking.at.Airport+Class
        +Departure.Delay.in.Minutes+Arrival.Delay.in.Minutes+Flight.cancelled
        ,data=flyFast)

summary(lm2)

lm3<-lm(Likelihood.to.recommend~Age+Airline.Status+Gender+Price.Sensitivity+Year.of.First.Flight+Flights.Per.Year
        +Loyalty+Type.of.Travel
        +Eating.and.Drinking.at.Airport+Class
        +Departure.Delay.in.Minutes+Flight.cancelled
        ,data=dfx)

summary(lm3)

max(dfx$Eating.and.Drinking.at.Airport)

lm4<-lm(Likelihood.to.recommend~Age+Airline.Status+Gender+Price.Sensitivity+Flights.Per.Year
        +Type.of.Travel
        +Eating.and.Drinking.at.Airport+Class
        +Departure.Delay.in.Minutes+Flight.cancelled
        ,data=dfx)

summary(lm4)

fFlm<-lm(Likelihood.to.recommend~Age+Airline.Status+Gender+Price.Sensitivity+Flights.Per.Year
        +Type.of.Travel
        +Eating.and.Drinking.at.Airport+Class
        +Departure.Delay.in.Minutes+Flight.cancelled
        ,data=flyFast)

#fFlm<-lm(Likelihood.to.recommend~Age+Airline.Status+Gender+Price.Sensitivity+Flights.Per.Year
         +Type.of.Travel
         +Eating.and.Drinking.at.Airport+Class
         +Departure.Delay.in.Minutes+Flight.cancelled
         ,data=flyFast)

#summary(lm4)
flyFast$Likelihood.to.recommend <- as.numeric(flyFast$Likelihood.to.recommend)
fFlm<-lm(Likelihood.to.recommend~Age+Airline.Status+Gender+Price.Sensitivity+Year.of.First.Flight+Flights.Per.Year
        +Loyalty+Type.of.Travel+Total.Freq.Flyer.Accts+Shopping.Amount.at.Airport
        +Eating.and.Drinking.at.Airport+Class
        +Departure.Delay.in.Minutes+Arrival.Delay.in.Minutes+Flight.cancelled
        ,data=flyFast)

summary(fFlm)

# Prime data
dfm <- dataset
dfm$Likelihood.to.recommend[is.na(dfm$Likelihood.to.recommend)]<- 7

dfm[930,25]   <- 251
dfm[1224,25]  <- 128
dfm[1504,25]  <- 326
dfm[2398,25]  <- 137
dfm[3486,25]  <- 62
dfm[3655,25]  <- 214
dfm[3686,25]  <- 240
dfm[3695,25]  <- 197
dfm[3789,25]  <- 88
dfm[4219,25]  <- 192
dfm[4949,25]  <- 75
dfm[5083,25]  <- 121
dfm[5152,25]  <- 237
dfm[6111,25]  <- 121
dfm[6125,25]  <- 174
dfm[6831,25]  <- 73
dfm[7465,25]  <- 113
dfm[8384,25]  <- 113
dfm[8840,25]  <- 197
dfm[9266,25]  <- 104
dfm[9994,25]  <- 236
 
dfm[dfm$Flight.cancelled == 'Yes',25] <- 0 

dfm[which(is.na(dfm$Arrival.Delay.in.Minutes), arr.ind = TRUE),23] <- dfm[which(is.na(dfm$Arrival.Delay.in.Minutes), arr.ind = TRUE),22]

dfm[dfm$Flight.cancelled == 'Yes',23] <- 0 

dfm[which(is.na(dfm$Departure.Delay.in.Minutes), arr.ind = TRUE),22] <- 0
dfm1 <- dfm[,c(3,4,5,6,8,10,13,14,18,27)]
dfm1$Likelihood.to.recommend[dfm1$Likelihood.to.recommend<7] <- 0 
dfm1$Likelihood.to.recommend[dfm1$Likelihood.to.recommend>=7] <- 1 
dfm1$Likelihood.to.recommend <- as.factor(dfm1$Likelihood.to.recommend)
dfm1$Age <- as.factor(dfm1$Age)
dfm1$Price.Sensitivity <- as.factor(dfm1$Price.Sensitivity)
dfm1$Flights.Per.Year <- as.factor(dfm1$Flights.Per.Year)
dfm1$Eating.and.Drinking.at.Airport <- as.factor(dfm1$Eating.and.Drinking.at.Airport)

# SVM
dfmx <- as(dfm1, "transactions")
itemFrequencyPlot(dfmx)

ruleset <- apriori(dfmx,
                   parameter = list(support = 0.005, confidence = 0.5),
                   appearance = list(default = "lhs", rhs=("Likelihood.to.recommend=1")))
inspect(ruleset)
inspectDT(ruleset)

# flyFast SVM
# Create flyFast svm data with only significant variables/ variables SouthEast Airlines can control
ffsvm <- flyFast[,c(6,9,12,13,14,22,23,24,27)]

# Group price sensitivity for less breaks. 0 = more sensitive to price, 1 = less sensitive to price
ffsvm$Price.Sensitivity <- replace(ffsvm$Price.Sensitivity, ffsvm$Price.Sensitivity >-1 & ffsvm$Price.Sensitivity <= 2, 1)
ffsvm$Price.Sensitivity <- replace(ffsvm$Price.Sensitivity, ffsvm$Price.Sensitivity >2 & ffsvm$Price.Sensitivity <= 5, 0)

# Grouping Loyalty for less breaks
ffsvm$Loyalty[ffsvm$Loyalty>0] <- 2 
ffsvm$Loyalty[ffsvm$Loyalty<=0] <- 3 
# Reassigning loyalty values to 0,1. 0 = no loyalty, 1 = loyal to company 
ffsvm$Loyalty[ffsvm$Loyalty == 2] <- 1 
ffsvm$Loyalty[ffsvm$Loyalty == 3] <- 0 

# Grouping shopping amount for less breaks. 0 = 0 spent, 1 = 1-25 spent, 2 = 26-50 spent, 3 = 51 - 100 spent, 4 = 101 - 200 spent, 5 = 201 - 300 spent, 6 = 301+ spent
ffsvm$Shopping.Amount.at.Airport <- replace(ffsvm$Shopping.Amount.at.Airport, ffsvm$Shopping.Amount.at.Airport > 1 & ffsvm$Shopping.Amount.at.Airport <= 25, 1)
ffsvm$Shopping.Amount.at.Airport <- replace(ffsvm$Shopping.Amount.at.Airport, ffsvm$Shopping.Amount.at.Airport > 2 & ffsvm$Shopping.Amount.at.Airport <= 50, 2)
ffsvm$Shopping.Amount.at.Airport <- replace(ffsvm$Shopping.Amount.at.Airport, ffsvm$Shopping.Amount.at.Airport > 50 & ffsvm$Shopping.Amount.at.Airport <= 100, 3)
ffsvm$Shopping.Amount.at.Airport <- replace(ffsvm$Shopping.Amount.at.Airport, ffsvm$Shopping.Amount.at.Airport > 100 & ffsvm$Shopping.Amount.at.Airport <= 200, 4)
ffsvm$Shopping.Amount.at.Airport <- replace(ffsvm$Shopping.Amount.at.Airport, ffsvm$Shopping.Amount.at.Airport > 200 & ffsvm$Shopping.Amount.at.Airport <= 300, 5)
ffsvm$Shopping.Amount.at.Airport <- replace(ffsvm$Shopping.Amount.at.Airport, ffsvm$Shopping.Amount.at.Airport > 300 & ffsvm$Shopping.Amount.at.Airport <= 5000, 6)

# Grouping eating amount for less breaks. 0 = 0 spent, 1 = 1-25 spent, 2 = 26-50 spent, 3 = 51 - 100 spent, 4 = 101 - 200 spent, 5 = 201 - 300 spent, 6 = 301+ spent
ffsvm$Eating.and.Drinking.at.Airport <- replace(ffsvm$Eating.and.Drinking.at.Airport, ffsvm$Eating.and.Drinking.at.Airport > 1 & ffsvm$Eating.and.Drinking.at.Airport <= 25, 1)
ffsvm$Eating.and.Drinking.at.Airport <- replace(ffsvm$Eating.and.Drinking.at.Airport, ffsvm$Eating.and.Drinking.at.Airport > 25 & ffsvm$Eating.and.Drinking.at.Airport <= 50, 2)
ffsvm$Eating.and.Drinking.at.Airport <- replace(ffsvm$Eating.and.Drinking.at.Airport, ffsvm$Eating.and.Drinking.at.Airport > 50 & ffsvm$Eating.and.Drinking.at.Airport <= 100, 3)
ffsvm$Eating.and.Drinking.at.Airport <- replace(ffsvm$Eating.and.Drinking.at.Airport, ffsvm$Eating.and.Drinking.at.Airport > 100 & ffsvm$Eating.and.Drinking.at.Airport <= 200, 4)
ffsvm$Eating.and.Drinking.at.Airport <- replace(ffsvm$Eating.and.Drinking.at.Airport, ffsvm$Eating.and.Drinking.at.Airport > 200 & ffsvm$Eating.and.Drinking.at.Airport <= 300, 5)
ffsvm$Eating.and.Drinking.at.Airport <- replace(ffsvm$Eating.and.Drinking.at.Airport, ffsvm$Eating.and.Drinking.at.Airport > 300 & ffsvm$Eating.and.Drinking.at.Airport <= 5000, 6)

# Grouping departure delay for less breaks. 0 = 0 delay, 1 = 1-25 delay, 2 = 26-50 delay, 3 = 51 - 100 delay, 4 = 101 - 200 delay, 5 = 201+ delay
ffsvm$Departure.Delay.in.Minutes <- replace(ffsvm$Departure.Delay.in.Minutes, ffsvm$Departure.Delay.in.Minutes > 1 & ffsvm$Departure.Delay.in.Minutes <= 25, 1)
ffsvm$Departure.Delay.in.Minutes <- replace(ffsvm$Departure.Delay.in.Minutes, ffsvm$Departure.Delay.in.Minutes > 25 & ffsvm$Departure.Delay.in.Minutes <= 50, 2)
ffsvm$Departure.Delay.in.Minutes <- replace(ffsvm$Departure.Delay.in.Minutes, ffsvm$Departure.Delay.in.Minutes > 50 & ffsvm$Departure.Delay.in.Minutes <= 100, 3)
ffsvm$Departure.Delay.in.Minutes <- replace(ffsvm$Departure.Delay.in.Minutes, ffsvm$Departure.Delay.in.Minutes > 100 & ffsvm$Departure.Delay.in.Minutes <= 200, 4)
ffsvm$Departure.Delay.in.Minutes <- replace(ffsvm$Departure.Delay.in.Minutes, ffsvm$Departure.Delay.in.Minutes > 200 & ffsvm$Departure.Delay.in.Minutes <= 2000, 5)

# Grouping arrival delay for less breaks. 0 = 0 delay, 1 = 1-25 delay, 2 = 26-50 delay, 3 = 51 - 100 delay, 4 = 101 - 200 delay, 5 = 201+ delay
ffsvm$Arrival.Delay.in.Minutes <- replace(ffsvm$Arrival.Delay.in.Minutes, ffsvm$Arrival.Delay.in.Minutes > 1 & ffsvm$Arrival.Delay.in.Minutes <= 25, 1)
ffsvm$Arrival.Delay.in.Minutes <- replace(ffsvm$Arrival.Delay.in.Minutes, ffsvm$Arrival.Delay.in.Minutes > 25 & ffsvm$Arrival.Delay.in.Minutes <= 50, 2)
ffsvm$Arrival.Delay.in.Minutes <- replace(ffsvm$Arrival.Delay.in.Minutes, ffsvm$Arrival.Delay.in.Minutes > 50 & ffsvm$Arrival.Delay.in.Minutes <= 100, 3)
ffsvm$Arrival.Delay.in.Minutes <- replace(ffsvm$Arrival.Delay.in.Minutes, ffsvm$Arrival.Delay.in.Minutes > 100 & ffsvm$Arrival.Delay.in.Minutes <= 200, 4)
ffsvm$Arrival.Delay.in.Minutes <- replace(ffsvm$Arrival.Delay.in.Minutes, ffsvm$Arrival.Delay.in.Minutes > 200 & ffsvm$Arrival.Delay.in.Minutes <= 2000, 5)

# Grouping NPS scores for less breaks. 0 = lower NPS, 1= Higher NPS
ffsvm$Likelihood.to.recommend[ffsvm$Likelihood.to.recommend<7] <- 0 
ffsvm$Likelihood.to.recommend[ffsvm$Likelihood.to.recommend>=7] <- 1 

# Converting all numeric columns to a factor for the SVM
ffsvm$Likelihood.to.recommend <- as.factor(ffsvm$Likelihood.to.recommend)
ffsvm$Price.Sensitivity <- as.factor(ffsvm$Price.Sensitivity)
ffsvm$Loyalty <- as.factor(ffsvm$Loyalty)
ffsvm$Shopping.Amount.at.Airport <- as.factor(ffsvm$Shopping.Amount.at.Airport)
ffsvm$Eating.and.Drinking.at.Airport <- as.factor(ffsvm$Eating.and.Drinking.at.Airport)
ffsvm$Departure.Delay.in.Minutes <- as.factor(ffsvm$Departure.Delay.in.Minutes)
ffsvm$Arrival.Delay.in.Minutes <- as.factor(ffsvm$Arrival.Delay.in.Minutes)

# Coerece the data as transactions
ffsvmx1 <- as(ffsvm, "transactions")
itemFrequencyPlot(ffsvmx1)

# Create the ruleset to determine what variables give a higher NPS
ffsvmRuleset1 <- apriori(ffsvmx1,
                   parameter = list(support = 0.005, confidence = 0.5),
                   appearance = list(default = "lhs", rhs=("Likelihood.to.recommend=1")))
inspect(ffsvmRuleset1)
inspectDT(ffsvmRuleset1)

# Create the ruleset to determine what variables give a lower NPS
ffsvmRuleset1Low <- apriori(ffsvmx1,
                         parameter = list(support = 0.005, confidence = 0.5),
                         appearance = list(default = "lhs", rhs=("Likelihood.to.recommend=0")))
inspectDT(ffsvmRuleset1Low)

# oursinAir SVM

# Create oursinAir svm data with only significant variables/ variables SouthEast Airlines can control
oasvm <- oursinAir[,c(6,9,12,13,14,22,23,24,27)]

# Group price sensitivity for less breaks. 0 = more sensitive to price, 1 = less sensitive to price
oasvm$Price.Sensitivity <- replace(oasvm$Price.Sensitivity, oasvm$Price.Sensitivity >-1 & oasvm$Price.Sensitivity <= 2, 1)
oasvm$Price.Sensitivity <- replace(oasvm$Price.Sensitivity, oasvm$Price.Sensitivity >2 & oasvm$Price.Sensitivity <= 5, 0)

# Grouping Loyalty for less breaks
oasvm$Loyalty[oasvm$Loyalty>0] <- 2 
oasvm$Loyalty[oasvm$Loyalty<=0] <- 3 
# Reassigning loyalty values to 0,1. 0 = no loyalty, 1 = loyal to company 
oasvm$Loyalty[oasvm$Loyalty == 2] <- 1 
oasvm$Loyalty[oasvm$Loyalty == 3] <- 0 

# Grouping shopping amount for less breaks. 0 = 0 spent, 1 = 1-25 spent, 2 = 26-50 spent, 3 = 51 - 100 spent, 4 = 101 - 200 spent, 5 = 201 - 300 spent, 6 = 301+ spent
oasvm$Shopping.Amount.at.Airport <- replace(oasvm$Shopping.Amount.at.Airport, oasvm$Shopping.Amount.at.Airport > 1 & oasvm$Shopping.Amount.at.Airport <= 25, 1)
oasvm$Shopping.Amount.at.Airport <- replace(oasvm$Shopping.Amount.at.Airport, oasvm$Shopping.Amount.at.Airport > 2 & oasvm$Shopping.Amount.at.Airport <= 50, 2)
oasvm$Shopping.Amount.at.Airport <- replace(oasvm$Shopping.Amount.at.Airport, oasvm$Shopping.Amount.at.Airport > 50 & oasvm$Shopping.Amount.at.Airport <= 100, 3)
oasvm$Shopping.Amount.at.Airport <- replace(oasvm$Shopping.Amount.at.Airport, oasvm$Shopping.Amount.at.Airport > 100 & oasvm$Shopping.Amount.at.Airport <= 200, 4)
oasvm$Shopping.Amount.at.Airport <- replace(oasvm$Shopping.Amount.at.Airport, oasvm$Shopping.Amount.at.Airport > 200 & oasvm$Shopping.Amount.at.Airport <= 300, 5)
oasvm$Shopping.Amount.at.Airport <- replace(oasvm$Shopping.Amount.at.Airport, oasvm$Shopping.Amount.at.Airport > 300 & oasvm$Shopping.Amount.at.Airport <= 5000, 6)

# Grouping eating amount for less breaks. 0 = 0 spent, 1 = 1-25 spent, 2 = 26-50 spent, 3 = 51 - 100 spent, 4 = 101 - 200 spent, 5 = 201 - 300 spent, 6 = 301+ spent
oasvm$Eating.and.Drinking.at.Airport <- replace(oasvm$Eating.and.Drinking.at.Airport, oasvm$Eating.and.Drinking.at.Airport > 1 & oasvm$Eating.and.Drinking.at.Airport <= 25, 1)
oasvm$Eating.and.Drinking.at.Airport <- replace(oasvm$Eating.and.Drinking.at.Airport, oasvm$Eating.and.Drinking.at.Airport > 25 & oasvm$Eating.and.Drinking.at.Airport <= 50, 2)
oasvm$Eating.and.Drinking.at.Airport <- replace(oasvm$Eating.and.Drinking.at.Airport, oasvm$Eating.and.Drinking.at.Airport > 50 & oasvm$Eating.and.Drinking.at.Airport <= 100, 3)
oasvm$Eating.and.Drinking.at.Airport <- replace(oasvm$Eating.and.Drinking.at.Airport, oasvm$Eating.and.Drinking.at.Airport > 100 & oasvm$Eating.and.Drinking.at.Airport <= 200, 4)
oasvm$Eating.and.Drinking.at.Airport <- replace(oasvm$Eating.and.Drinking.at.Airport, oasvm$Eating.and.Drinking.at.Airport > 200 & oasvm$Eating.and.Drinking.at.Airport <= 300, 5)
oasvm$Eating.and.Drinking.at.Airport <- replace(oasvm$Eating.and.Drinking.at.Airport, oasvm$Eating.and.Drinking.at.Airport > 300 & oasvm$Eating.and.Drinking.at.Airport <= 5000, 6)

# Grouping departure delay for less breaks. 0 = 0 delay, 1 = 1-25 delay, 2 = 26-50 delay, 3 = 51 - 100 delay, 4 = 101 - 200 delay, 5 = 201+ delay
oasvm$Departure.Delay.in.Minutes <- replace(oasvm$Departure.Delay.in.Minutes, oasvm$Departure.Delay.in.Minutes > 1 & oasvm$Departure.Delay.in.Minutes <= 25, 1)
oasvm$Departure.Delay.in.Minutes <- replace(oasvm$Departure.Delay.in.Minutes, oasvm$Departure.Delay.in.Minutes > 25 & oasvm$Departure.Delay.in.Minutes <= 50, 2)
oasvm$Departure.Delay.in.Minutes <- replace(oasvm$Departure.Delay.in.Minutes, oasvm$Departure.Delay.in.Minutes > 50 & oasvm$Departure.Delay.in.Minutes <= 100, 3)
oasvm$Departure.Delay.in.Minutes <- replace(oasvm$Departure.Delay.in.Minutes, oasvm$Departure.Delay.in.Minutes > 100 & oasvm$Departure.Delay.in.Minutes <= 200, 4)
oasvm$Departure.Delay.in.Minutes <- replace(oasvm$Departure.Delay.in.Minutes, oasvm$Departure.Delay.in.Minutes > 200 & oasvm$Departure.Delay.in.Minutes <= 2000, 5)

# Grouping arrival delay for less breaks. 0 = 0 delay, 1 = 1-25 delay, 2 = 26-50 delay, 3 = 51 - 100 delay, 4 = 101 - 200 delay, 5 = 201+ delay
oasvm$Arrival.Delay.in.Minutes <- replace(oasvm$Arrival.Delay.in.Minutes, oasvm$Arrival.Delay.in.Minutes > 1 & oasvm$Arrival.Delay.in.Minutes <= 25, 1)
oasvm$Arrival.Delay.in.Minutes <- replace(oasvm$Arrival.Delay.in.Minutes, oasvm$Arrival.Delay.in.Minutes > 25 & oasvm$Arrival.Delay.in.Minutes <= 50, 2)
oasvm$Arrival.Delay.in.Minutes <- replace(oasvm$Arrival.Delay.in.Minutes, oasvm$Arrival.Delay.in.Minutes > 50 & oasvm$Arrival.Delay.in.Minutes <= 100, 3)
oasvm$Arrival.Delay.in.Minutes <- replace(oasvm$Arrival.Delay.in.Minutes, oasvm$Arrival.Delay.in.Minutes > 100 & oasvm$Arrival.Delay.in.Minutes <= 200, 4)
oasvm$Arrival.Delay.in.Minutes <- replace(oasvm$Arrival.Delay.in.Minutes, oasvm$Arrival.Delay.in.Minutes > 200 & oasvm$Arrival.Delay.in.Minutes <= 2000, 5)

# Grouping NPS scores for less breaks. 0 = lower NPS, 1= Higher NPS
oasvm$Likelihood.to.recommend[oasvm$Likelihood.to.recommend<7] <- 0 
oasvm$Likelihood.to.recommend[oasvm$Likelihood.to.recommend>=7] <- 1

# Converting all numeric columns to a factor for the SVM
oasvm$Likelihood.to.recommend <- as.factor(oasvm$Likelihood.to.recommend)
oasvm$Price.Sensitivity <- as.factor(oasvm$Price.Sensitivity)
oasvm$Loyalty <- as.factor(oasvm$Loyalty)
oasvm$Shopping.Amount.at.Airport <- as.factor(oasvm$Shopping.Amount.at.Airport)
oasvm$Eating.and.Drinking.at.Airport <- as.factor(oasvm$Eating.and.Drinking.at.Airport)
oasvm$Departure.Delay.in.Minutes <- as.factor(oasvm$Departure.Delay.in.Minutes)
oasvm$Arrival.Delay.in.Minutes <- as.factor(oasvm$Arrival.Delay.in.Minutes)

# Coerece the data as transactions
oasvmx <- as(oasvm, "transactions")
itemFrequencyPlot(oasvmx)

# Create the ruleset to determine what variables give a higher NPS
oasvmRuleset <- apriori(oasvmx,
                         parameter = list(support = 0.005, confidence = 0.5),
                         appearance = list(default = "lhs", rhs=("Likelihood.to.recommend=1")))
inspect(oasvmRuleset)
inspectDT(oasvmRuleset)

# Create the ruleset to determine what variables give a lower NPS
oasvmRulesetLow <- apriori(oasvmx,
                            parameter = list(support = 0.005, confidence = 0.5),
                            appearance = list(default = "lhs", rhs=("Likelihood.to.recommend=0")))
inspectDT(oasvmRulesetLow)

# cheapSeat SVM
# Create cheapSeat svm data with only significant variables/ variables SouthEast Airlines can control
cssvm <- cheapSeats[,c(6,9,12,13,14,22,23,24,27)]

# Group price sensitivity for less breaks. 0 = more sensitive to price, 1 = less sensitive to price
cssvm$Price.Sensitivity <- replace(cssvm$Price.Sensitivity, cssvm$Price.Sensitivity >-1 & cssvm$Price.Sensitivity <= 2, 1)
cssvm$Price.Sensitivity <- replace(cssvm$Price.Sensitivity, cssvm$Price.Sensitivity >2 & cssvm$Price.Sensitivity <= 5, 0)

# Grouping Loyalty for less breaks
cssvm$Loyalty[cssvm$Loyalty>0] <- 2 
cssvm$Loyalty[cssvm$Loyalty<=0] <- 3 
# Reassigning loyalty values to 0,1. 0 = no loyalty, 1 = loyal to company 
cssvm$Loyalty[cssvm$Loyalty == 2] <- 1 
cssvm$Loyalty[cssvm$Loyalty == 3] <- 0 

# Grouping shopping amount for less breaks. 0 = 0 spent, 1 = 1-25 spent, 2 = 26-50 spent, 3 = 51 - 100 spent, 4 = 101 - 200 spent, 5 = 201 - 300 spent, 6 = 301+ spent
cssvm$Shopping.Amount.at.Airport <- replace(cssvm$Shopping.Amount.at.Airport, cssvm$Shopping.Amount.at.Airport > 1 & cssvm$Shopping.Amount.at.Airport <= 25, 1)
cssvm$Shopping.Amount.at.Airport <- replace(cssvm$Shopping.Amount.at.Airport, cssvm$Shopping.Amount.at.Airport > 2 & cssvm$Shopping.Amount.at.Airport <= 50, 2)
cssvm$Shopping.Amount.at.Airport <- replace(cssvm$Shopping.Amount.at.Airport, cssvm$Shopping.Amount.at.Airport > 50 & cssvm$Shopping.Amount.at.Airport <= 100, 3)
cssvm$Shopping.Amount.at.Airport <- replace(cssvm$Shopping.Amount.at.Airport, cssvm$Shopping.Amount.at.Airport > 100 & cssvm$Shopping.Amount.at.Airport <= 200, 4)
cssvm$Shopping.Amount.at.Airport <- replace(cssvm$Shopping.Amount.at.Airport, cssvm$Shopping.Amount.at.Airport > 200 & cssvm$Shopping.Amount.at.Airport <= 300, 5)
cssvm$Shopping.Amount.at.Airport <- replace(cssvm$Shopping.Amount.at.Airport, cssvm$Shopping.Amount.at.Airport > 300 & cssvm$Shopping.Amount.at.Airport <= 5000, 6)

# Grouping eating amount for less breaks. 0 = 0 spent, 1 = 1-25 spent, 2 = 26-50 spent, 3 = 51 - 100 spent, 4 = 101 - 200 spent, 5 = 201 - 300 spent, 6 = 301+ spent
cssvm$Eating.and.Drinking.at.Airport <- replace(cssvm$Eating.and.Drinking.at.Airport, cssvm$Eating.and.Drinking.at.Airport > 1 & cssvm$Eating.and.Drinking.at.Airport <= 25, 1)
cssvm$Eating.and.Drinking.at.Airport <- replace(cssvm$Eating.and.Drinking.at.Airport, cssvm$Eating.and.Drinking.at.Airport > 25 & cssvm$Eating.and.Drinking.at.Airport <= 50, 2)
cssvm$Eating.and.Drinking.at.Airport <- replace(cssvm$Eating.and.Drinking.at.Airport, cssvm$Eating.and.Drinking.at.Airport > 50 & cssvm$Eating.and.Drinking.at.Airport <= 100, 3)
cssvm$Eating.and.Drinking.at.Airport <- replace(cssvm$Eating.and.Drinking.at.Airport, cssvm$Eating.and.Drinking.at.Airport > 100 & cssvm$Eating.and.Drinking.at.Airport <= 200, 4)
cssvm$Eating.and.Drinking.at.Airport <- replace(cssvm$Eating.and.Drinking.at.Airport, cssvm$Eating.and.Drinking.at.Airport > 200 & cssvm$Eating.and.Drinking.at.Airport <= 300, 5)
cssvm$Eating.and.Drinking.at.Airport <- replace(cssvm$Eating.and.Drinking.at.Airport, cssvm$Eating.and.Drinking.at.Airport > 300 & cssvm$Eating.and.Drinking.at.Airport <= 5000, 6)

# Grouping departure delay for less breaks. 0 = 0 delay, 1 = 1-25 delay, 2 = 26-50 delay, 3 = 51 - 100 delay, 4 = 101 - 200 delay, 5 = 201+ delay
cssvm$Departure.Delay.in.Minutes <- replace(cssvm$Departure.Delay.in.Minutes, cssvm$Departure.Delay.in.Minutes > 1 & cssvm$Departure.Delay.in.Minutes <= 25, 1)
cssvm$Departure.Delay.in.Minutes <- replace(cssvm$Departure.Delay.in.Minutes, cssvm$Departure.Delay.in.Minutes > 25 & cssvm$Departure.Delay.in.Minutes <= 50, 2)
cssvm$Departure.Delay.in.Minutes <- replace(cssvm$Departure.Delay.in.Minutes, cssvm$Departure.Delay.in.Minutes > 50 & cssvm$Departure.Delay.in.Minutes <= 100, 3)
cssvm$Departure.Delay.in.Minutes <- replace(cssvm$Departure.Delay.in.Minutes, cssvm$Departure.Delay.in.Minutes > 100 & cssvm$Departure.Delay.in.Minutes <= 200, 4)
cssvm$Departure.Delay.in.Minutes <- replace(cssvm$Departure.Delay.in.Minutes, cssvm$Departure.Delay.in.Minutes > 200 & cssvm$Departure.Delay.in.Minutes <= 2000, 5)

# Grouping arrival delay for less breaks. 0 = 0 delay, 1 = 1-25 delay, 2 = 26-50 delay, 3 = 51 - 100 delay, 4 = 101 - 200 delay, 5 = 201+ delay
cssvm$Arrival.Delay.in.Minutes <- replace(cssvm$Arrival.Delay.in.Minutes, cssvm$Arrival.Delay.in.Minutes > 1 & cssvm$Arrival.Delay.in.Minutes <= 25, 1)
cssvm$Arrival.Delay.in.Minutes <- replace(cssvm$Arrival.Delay.in.Minutes, cssvm$Arrival.Delay.in.Minutes > 25 & cssvm$Arrival.Delay.in.Minutes <= 50, 2)
cssvm$Arrival.Delay.in.Minutes <- replace(cssvm$Arrival.Delay.in.Minutes, cssvm$Arrival.Delay.in.Minutes > 50 & cssvm$Arrival.Delay.in.Minutes <= 100, 3)
cssvm$Arrival.Delay.in.Minutes <- replace(cssvm$Arrival.Delay.in.Minutes, cssvm$Arrival.Delay.in.Minutes > 100 & cssvm$Arrival.Delay.in.Minutes <= 200, 4)
cssvm$Arrival.Delay.in.Minutes <- replace(cssvm$Arrival.Delay.in.Minutes, cssvm$Arrival.Delay.in.Minutes > 200 & cssvm$Arrival.Delay.in.Minutes <= 2000, 5)

# Grouping NPS scores for less breaks. 0 = lower NPS, 1= Higher NPS
cssvm$Likelihood.to.recommend[cssvm$Likelihood.to.recommend<7] <- 0 
cssvm$Likelihood.to.recommend[cssvm$Likelihood.to.recommend>=7] <- 1 

# Converting all numeric columns to a factor for the SVM
cssvm$Likelihood.to.recommend <- as.factor(cssvm$Likelihood.to.recommend)
cssvm$Price.Sensitivity <- as.factor(cssvm$Price.Sensitivity)
cssvm$Loyalty <- as.factor(cssvm$Loyalty)
cssvm$Shopping.Amount.at.Airport <- as.factor(cssvm$Shopping.Amount.at.Airport)
cssvm$Eating.and.Drinking.at.Airport <- as.factor(cssvm$Eating.and.Drinking.at.Airport)
cssvm$Departure.Delay.in.Minutes <- as.factor(cssvm$Departure.Delay.in.Minutes)
cssvm$Arrival.Delay.in.Minutes <- as.factor(cssvm$Arrival.Delay.in.Minutes)

# Coerece the data as transactions
cssvmx <- as(cssvm, "transactions")
itemFrequencyPlot(cssvmx)

# Create the ruleset to determine what variables give a higher NPS
cssvmRuleset <- apriori(cssvmx,
                        parameter = list(support = 0.005, confidence = 0.5),
                        appearance = list(default = "lhs", rhs=("Likelihood.to.recommend=1")))
inspect(cssvmRuleset)
inspectDT(cssvmRuleset)


# Create the ruleset to determine what variables give a lower NPS
cssvmRulesetLow <- apriori(cssvmx,
                           parameter = list(support = 0.005, confidence = 0.5),
                           appearance = list(default = "lhs", rhs=("Likelihood.to.recommend=0")))
inspectDT(cssvmRulesetLow)


# age
groupcs <- cheapSeats

groupcs$Age <- replace(groupcs$Age, groupcs$Age > 1 & groupcs$Age <= 25, 0)
groupcs$Age <- replace(groupcs$Age, groupcs$Age > 25 & groupcs$Age <= 35, 1)
groupcs$Age <- replace(groupcs$Age, groupcs$Age > 35 & groupcs$Age <= 45, 2)
groupcs$Age <- replace(groupcs$Age, groupcs$Age > 45 & groupcs$Age <= 55, 3)
groupcs$Age <- replace(groupcs$Age, groupcs$Age > 55 & groupcs$Age <= 65, 4)
groupcs$Age <- replace(groupcs$Age, groupcs$Age > 65 & groupcs$Age <= 75, 5)
groupcs$Age <- replace(groupcs$Age, groupcs$Age > 75 & groupcs$Age <= 85, 6)

groupcs0 <- groupcs [ which(groupcs$Age == 0), ]
groupcs0$Likelihood.to.recommend <- mean(groupcs0$Likelihood.to.recommend)

groupcs1 <- groupcs [ which(groupcs$Age == 1), ]
groupcs1$Likelihood.to.recommend <- mean(groupcs1$Likelihood.to.recommend)

groupcs2 <- groupcs [ which(groupcs$Age == 2), ]
groupcs2$Likelihood.to.recommend <- mean(groupcs2$Likelihood.to.recommend)

groupcs3 <- groupcs [ which(groupcs$Age == 3), ]
groupcs3$Likelihood.to.recommend <- mean(groupcs3$Likelihood.to.recommend)

groupcs4 <- groupcs [ which(groupcs$Age == 4), ]
groupcs4$Likelihood.to.recommend <- mean(groupcs4$Likelihood.to.recommend)

groupcs5 <- groupcs [ which(groupcs$Age == 5), ]
groupcs5$Likelihood.to.recommend <- mean(groupcs5$Likelihood.to.recommend)

groupcs6 <- groupcs [ which(groupcs$Age == 6), ]
groupcs6$Likelihood.to.recommend <- mean(groupcs6$Likelihood.to.recommend)

total <- merge(groupcs0, groupcs1, groupcs2, groupcs3, groupcs4, groupcs5, groupcs6, by="Partner.Name")

#plotcs0 <-  ggplot(data = groupcs0, aes(x=Age, y=Likelihood.to.recommend)) + geom_bar(stat = "identity", fill = groupcs0$Likelihood.to.recommend)
#plotcs0

total <- rbind(groupcs0, groupcs1)
total <- rbind(total, groupcs2)
total <- rbind(total, groupcs3)
total <- rbind(total, groupcs4)
total <- rbind(total, groupcs5)
total <- rbind(total, groupcs6)

plotcs0 <-  ggplot(data = total, aes(x=Age, y=Likelihood.to.recommend)) + geom_bar(stat = "identity")
plotcs0

low3 <- rbind(cssvm, oasvm, ffsvm)

# Coerece the data as transactions
low3svm <- as(low3, "transactions")
itemFrequencyPlot(low3svm)

# Create the ruleset to determine what variables give a higher NPS
low3Ruleset <- apriori(low3svm,
                        parameter = list(support = 0.005, confidence = 0.5),
                        appearance = list(default = "lhs", rhs=("Likelihood.to.recommend=1")))
inspect(low3Ruleset)
inspectDT(low3Ruleset)


# Create the ruleset to determine what variables give a lower NPS
low3RulesetLow <- apriori(low3svm,
                           parameter = list(support = 0.005, confidence = 0.5),
                           appearance = list(default = "lhs", rhs=("Likelihood.to.recommend=0")))
inspectDT(low3RulesetLow)












