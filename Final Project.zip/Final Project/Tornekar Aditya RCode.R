

####################################################Creating Dataframe from JSON##############################

# install.packages("RCurl")
# library(RCurl)
# install.packages("jsonlite")
# library(jsonlite)

#Use the updated link if required
dataset <- getURL("https://s3.us-east-1.amazonaws.com/blackboard.learn.xythos.prod/5956621d575cd/8614406?response-content-disposition=inline%3B%20filename%2A%3DUTF-8%27%27fall2019-survey-M02%25281%2529.json&response-content-type=application%2Fjson&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20191122T210821Z&X-Amz-SignedHeaders=host&X-Amz-Expires=21600&X-Amz-Credential=AKIAIL7WQYDOOHAZJGWQ%2F20191122%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Signature=f31190d2764559ba9ef31348732cafe9e2a415fa09da8b134e7464c85c40f3da")
df <- jsonlite::fromJSON(dataset)

#Created dataframe from the json file
projectData <- df

#Installing xslx package 
#https://cimentadaj.github.io/blog/2018-05-25-installing-rjava-on-windows-10/installing-rjava-on-windows-10/
#install.packages("rJava")
#Sys.setenv(JAVA_HOME="C:/Program Files/Java/jdk-13.0.1/")
#library(rJava)
#install.packages("xlsx")
#library(xlsx)
#write.xlsx(projectData,"C:\\Users\\ADITYA TORNEKAR\\Desktop\\01Syracuse Course Work\\Semester 1\\IST 687 Introduction To Data Science\\projectData.xlsx")


#####################################################Data Munging##############################################

 
#Departure.Delay.in.Minutes: Departure delay in minutes was NA only when a flight was cancelled(208 observations), this was changed to 0 as the flight was cancelled.

projectData[which(is.na(projectData$Departure.Delay.in.Minutes), arr.ind = TRUE),22] <- 0

# Arrival.Delay.in.Minutes: 
# Arrival delay had "NA" values for 235 observations, regardless of flight being cancelled or not.
# a) For cancelled flights: This was transformed and set to 0 as the flight was cancelled.

projectData[projectData$Flight.cancelled == 'Yes',23] <- 0 

#projectData[which(is.na(projectData$Arrival.Delay.in.Minutes), arr.ind = TRUE),23] 
#projectData[which(is.na(projectData$Arrival.Delay.in.Minutes), arr.ind = TRUE),23] 


# b)For non cancelled flights: We can use the departure delay time column which is the minimum amount of delay that is possible for arrival delay time.
# Here after the NAs are handled for cancelled flights only NAs present are for non cancelled flights
projectData[which(is.na(projectData$Arrival.Delay.in.Minutes), arr.ind = TRUE),23] <- projectData[which(is.na(projectData$Arrival.Delay.in.Minutes), arr.ind = TRUE),22]


# 3)Flight.time.in.minutes
# This variable had "NA" values for 235 observations.
# a) For cancelled flights(214 rows): This was transformed and set to 0 as the flight was cancelled.

projectData[projectData$Flight.cancelled == 'Yes',25] <- 0 

# b) For non-cancelled flights(21 rows): "NA" values in this scenario were handled by taking average of flight time of other flights which had the same flight distance.

#projectData[which(is.na(projectData$Flight.time.in.minutes), arr.ind = TRUE),25]
#projectData[which(is.na(projectData$Flight.time.in.minutes), arr.ind = TRUE),]

projectData[930,25]   <- 251
projectData[1224,25]  <- 128
projectData[1504,25]  <- 326
projectData[2398,25]  <- 137
projectData[3486,25]  <- 62
projectData[3655,25]  <- 214
projectData[3686,25]  <- 240
projectData[3695,25]  <- 197
projectData[3789,25]  <- 88
projectData[4219,25]  <- 192
projectData[4949,25]  <- 75
projectData[5083,25]  <- 121
projectData[5152,25]  <- 237
projectData[6111,25]  <- 121
projectData[6125,25]  <- 174
projectData[6831,25]  <- 73
projectData[7465,25]  <- 113
projectData[8384,25]  <- 113
projectData[8840,25]  <- 197
projectData[9266,25]  <- 104
projectData[9994,25]  <- 236

# 4)Likelihood.to.recommend
# This variable just had one "NA" value which was converted to a passive score of 7. (1-6 Detractors, 7-8 Passive, 9-10 Promoters)

projectData[which(is.na(projectData$Likelihood.to.recommend), arr.ind = TRUE),27] <- 7

################ Now only NAs present should be in the freeText column ##############################################################


View(projectData) #Original dataset with duplicates
cleanedProjectData <- unique(projectData) #Removing duplicate rows
View(cleanedProjectData)

#write.xlsx(cleanedProjectData,"C:\\Users\\ADITYA TORNEKAR\\Desktop\\01Syracuse Course Work\\Semester 1\\IST 687 Introduction To Data Science\\cleanedProjectData.xlsx")

###################################################### Data Munging Process Completed ##########################################################################################

###################################################### Linear Regression #######################################################################################################

# Initial Linear Model

lm1 <- lm(Likelihood.to.recommend~Airline.Status
          +Age
          +Gender
          +Price.Sensitivity
          +Year.of.First.Flight
          +Flights.Per.Year
          +Loyalty
          +Type.of.Travel
          +Total.Freq.Flyer.Accts
          +Shopping.Amount.at.Airport
          +Eating.and.Drinking.at.Airport
          +Class
          +Partner.Code
          +Partner.Name
          +Scheduled.Departure.Hour
          +Departure.Delay.in.Minutes
          +Arrival.Delay.in.Minutes
          +Flight.cancelled
          +Flight.time.in.minutes
          +Flight.Distance
          +olong
          +olat
          +dlong
          +dlat
          ,data = cleanedProjectData)

# After analysising multiple Linear models below data subset was most impacting Likelihood To Recommend variable.

############################################## Data subset based on inital linear model ############################################################

ModelData <- cleanedProjectData[ (cleanedProjectData$Class == "Eco" | cleanedProjectData$Class == "Business")
                                 & (cleanedProjectData$Type.of.Travel == "Personal Travel" | cleanedProjectData$Type.of.Travel == "Business travel")
                                 & (cleanedProjectData$Partner.Code == "AS" | cleanedProjectData$Partner.Code == "EV" | cleanedProjectData$Partner.Code == "OU")
                                 & (cleanedProjectData$Airline.Status == "Gold" | cleanedProjectData$Airline.Status == "Silver" | cleanedProjectData$Airline.Status == "Blue"),]

############################################### Final Model used for analysis ######################################################################

lm8 <- lm(Likelihood.to.recommend~Airline.Status
          +Age
          +Gender
          +Flights.Per.Year
          +Loyalty
          +Shopping.Amount.at.Airport
          +Eating.and.Drinking.at.Airport
          +Arrival.Delay.in.Minutes
          +olat
          +Class
          +Type.of.Travel
          +Partner.Code 
          ,data = ModelData)

summary(lm8)

###################################################### Visualizations ##################################################################################

library(ggplot2)

# Airline Status: Silver status customers are the ones to boost the Likelihood to recommend,followed by gold,blue,platinum status customers.
# Each tuple of 3 silver status customers boosts the net recommendation score by 4 as compared to gold and blue status customers
##Subset Data visualization
ggairstatus <- ggplot(ModelData,aes(x=Airline.Status,y=Likelihood.to.recommend))+geom_point()+stat_smooth(method = "lm",col = "red")
ggairstatus
ggairstatusbar <- ggplot(ModelData,aes(x=Airline.Status,y=mean(Likelihood.to.recommend))) + stat_summary(fun.y = "mean", geom = "bar")
ggairstatusbar
#Overall Data visualization
ggairstatuso <- ggplot(cleanedProjectData,aes(x=Airline.Status,y=mean(Likelihood.to.recommend))) + stat_summary(fun.y = "mean", geom = "bar")
ggairstatuso


# AGE: As the age increases, a customer tends to give negative recommendation score(every 10 years bring 5% lower recommendation score)
##Subset Data visualization
ggAget <- ggplot(ModelData,aes(x=Age,y=Likelihood.to.recommend)) + geom_point() + stat_smooth(method = "lm", col = "red")
ggAget
#Overall Data visualization
ggAgeo <- ggplot(cleanedProjectData,aes(x=Age,y=Likelihood.to.recommend)) + geom_point() + stat_smooth(method = "lm", col = "red")
ggAgeo


#Gender: Males tend to give better recommendation scores
##Subset Data visualization
gggendert <- ggplot(ModelData,aes(x=Gender,y=mean(Likelihood.to.recommend))) + stat_summary(fun.y = "mean", geom = "bar")
gggendert
#Overall Data visualization
gggendero <- ggplot(cleanedProjectData,aes(x=Gender,y=mean(Likelihood.to.recommend))) + stat_summary(fun.y = "mean", geom = "bar")
gggendero


#Flights per year: As the number of flights taken by a customer in a year increase, 
#for each extra flight customers tend to give 0.1% lower recommendation scores.
##Subset Data visualization
ggFlightsPerYearo <- ggplot(ModelData,aes(x=Flights.Per.Year,y=Likelihood.to.recommend)) + geom_point() + stat_smooth(method = "lm", col = "red")
ggFlightsPerYearo
#Overall Data visualization
ggFlightsPerYeart <- ggplot(cleanedProjectData,aes(x=Flights.Per.Year,y=Likelihood.to.recommend)) + geom_point() + stat_smooth(method = "lm", col = "red")
ggFlightsPerYeart


# Eating & drinking at the airport: Customers who eat & drink at the airport tend to give positive recommendations.
# Each 100$ spent on eating & drinking at the airport translates to increased 4% recommendation score
##Subset Data visualization
ggEatingDrinkingo <- ggplot(ModelData,aes(x=Eating.and.Drinking.at.Airport,y=Likelihood.to.recommend)) + geom_point() + stat_smooth(method = "lm", col = "red")
ggEatingDrinkingo
#Overall Data visualization
ggEatingDrinkingt <- ggplot(cleanedProjectData,aes(x=Eating.and.Drinking.at.Airport,y=Likelihood.to.recommend)) + geom_point() + stat_smooth(method = "lm", col = "red")
ggEatingDrinkingt


# Shopping at the airport: More the amount spent at the airport on shopping better the recommendation score. 
# Each 100$ spent on shopping translates to increased 1% recommendation score
##Subset Data visualization
ggShoppingo <- ggplot(ModelData,aes(x=Shopping.Amount.at.Airport,y=Likelihood.to.recommend)) + geom_point() + stat_smooth(method = "lm", col = "red")
ggShoppingo
#Overall Data visualization
ggShoppingt <- ggplot(cleanedProjectData,aes(x=Shopping.Amount.at.Airport,y=Likelihood.to.recommend)) + geom_point() + stat_smooth(method = "lm", col = "red")
ggShoppingt


#Arrival delay: Every hour of delay during arrival brings down recommendation score by 2.4%
##Subset Data visualization
ggArrivalDelayo <- ggplot(ModelData,aes(x=Arrival.Delay.in.Minutes,y=Likelihood.to.recommend)) + geom_point() + stat_smooth(method = "lm", col = "red")
ggArrivalDelayo
#Overall Data visualization
ggArrivalDelayt <- ggplot(cleanedProjectData,aes(x=Arrival.Delay.in.Minutes,y=Likelihood.to.recommend)) + geom_point() + stat_smooth(method = "lm", col = "red")
ggArrivalDelayt

#Type of travel: Customers traveling for personal work tend to give a negative 2.58 as compared to customers traveling for business reasons. 
#The below graph shows average recommendation scores for each type of travel considered.
##Subset Data visualization
ggTypeoftravelo <- ggplot(ModelData,aes(x=Type.of.Travel,y=Likelihood.to.recommend)) + stat_summary(fun.y = "mean", geom = "bar")
ggTypeoftravelo
#Overall Data visualization
ggTypeoftravelt <- ggplot(cleanedProjectData,aes(x=Type.of.Travel,y=Likelihood.to.recommend)) + stat_summary(fun.y = "mean", geom = "bar")
ggTypeoftravelt

#Loyalty: Overall Loyal customers tend to give better recommendation scores. 
##Subset Data visualization
ggLoyaltyo <- ggplot(cleanedProjectData,aes(x=Loyalty,y=Likelihood.to.recommend)) + geom_point() + stat_smooth(method = "lm", col = "red")
ggLoyaltyo
#Overall Data visualization
ggLoyaltyt <- ggplot(cleanedProjectData,aes(x=Loyalty,y=Likelihood.to.recommend)) + geom_point() + stat_smooth(method = "lm", col = "red")
ggLoyaltyt

#Business Class vs Economic Class
ggClass <- ggplot(ModelData,aes(x=Class,y=Likelihood.to.recommend)) + stat_summary(fun.y = "mean", geom = "bar")
ggClass


############################################# Filtered Airline Dataframes for Linear Regression Analysis #######################

CoolYoung_Airlines_IncData <- cleanedProjectData[ (cleanedProjectData$Partner.Name == "Cool&Young Airlines Inc."),]
EnjoyFlying_Air_ServicesData <- cleanedProjectData[ (cleanedProjectData$Partner.Name == "EnjoyFlying Air Services"),]
FlyHere_AirwaysData <- cleanedProjectData[ (cleanedProjectData$Partner.Name == "FlyHere Airways"),]
FlyToSun_Airlines_IncData <- cleanedProjectData[ (cleanedProjectData$Partner.Name == "FlyToSun Airlines Inc."),]
GoingNorth_Airlines_IncData <- cleanedProjectData[ (cleanedProjectData$Partner.Name == "GoingNorth Airlines Inc."),]
Northwest_Business_Airlines_IncData <- cleanedProjectData[ (cleanedProjectData$Partner.Name == "Northwest Business Airlines Inc."),]
OnlyJets_Airlines_IncData <- cleanedProjectData[ (cleanedProjectData$Partner.Name == "OnlyJets Airlines Inc."),]
Oursin_Airlines_IncData <- cleanedProjectData[ (cleanedProjectData$Partner.Name == "Oursin Airlines Inc."),]
Paul_Smith_Airlines_IncData <- cleanedProjectData[ (cleanedProjectData$Partner.Name == "Paul Smith Airlines Inc."),]
Sigma_Airlines_IncData <- cleanedProjectData[ (cleanedProjectData$Partner.Name == "Sigma Airlines Inc."),]
Southeast_Airlines_CoData <- cleanedProjectData[ (cleanedProjectData$Partner.Name == "Southeast Airlines Co."),]
West_Airways_IncData <- cleanedProjectData[ (cleanedProjectData$Partner.Name == "West Airways Inc."),]


###################################### Top 3 Airlines analysis based on number of customers ####################################

# Cheapseats Airlines Inc (2106 customers)
# Sigma Airlines Inc (1534 customers)
# FlyFast Airways Inc (1149 customers)

##################################### Cheapseats_Airlines_IncData 2106 customers #############################################

Cheapseats_Airlines_IncData <- cleanedProjectData[ (cleanedProjectData$Partner.Name == "Cheapseats Airlines Inc."),]
lm1Cheapseats_Airlines_IncData <- lm(Likelihood.to.recommend~
                                     +Airline.Status
                                     +Age
                                     +Gender
                                     +Price.Sensitivity
                                     +Year.of.First.Flight
                                     +Flights.Per.Year
                                     +Type.of.Travel
                                     +Eating.and.Drinking.at.Airport
                                     +Class
                                     +Scheduled.Departure.Hour
                                     +Departure.Delay.in.Minutes
                                     +Flight.Distance
                                     ,data = Cheapseats_Airlines_IncData)

summary(lm1Cheapseats_Airlines_IncData) 

########################################### Sigma Airlines Inc 1534 Customers ################################################

Sigma_Airlines_IncData <- cleanedProjectData[ (cleanedProjectData$Partner.Name == "Sigma Airlines Inc."),]

lm1Sigma_Airlines_IncData <- lm(Likelihood.to.recommend~
                                +Airline.Status
                                +Age
                                +Gender
                                +Type.of.Travel
                                +Eating.and.Drinking.at.Airport
                                +Scheduled.Departure.Hour
                                +Arrival.Delay.in.Minutes
                                ,data = Sigma_Airlines_IncData)

summary(lm1Sigma_Airlines_IncData)

########################################### FlyFast Airways Inc 1149 Customers ################################################

FlyFast_Airways_IncData <- cleanedProjectData[ (cleanedProjectData$Partner.Name == "FlyFast Airways Inc."),]

lm1FlyFast_Airways_IncData <- lm(Likelihood.to.recommend~
                                 +Airline.Status
                                 +Gender
                                 +Flights.Per.Year
                                 +Type.of.Travel
                                 +Eating.and.Drinking.at.Airport
                                 +Flight.cancelled
                                 +Flight.time.in.minutes
                                 +Flight.Distance
                                 ,data = FlyFast_Airways_IncData)

summary(lm1FlyFast_Airways_IncData)