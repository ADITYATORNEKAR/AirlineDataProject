setwd("//hd.ad.syr.edu/01/e3a6e0/Documents/Desktop/IST 687/Homework/Project")

library(RCurl)
library(jsonlite)

#df <- jsonlite::fromJSON("//hd.ad.syr.edu/01/e3a6e0/Documents/Desktop/IST 687/Homework/Project/fall2019-survey-M02.json")
#View(df)

library(tidyverse)
library(stringr)
library(arules)
library(arulesViz)

#############################
library(readxl)
dfnew <- read_excel("~/Desktop/IST 687/Homework/Project/dfnew.xlsx")
View(dfnew)

dfnew <- dfnew[,-1:-3]
dfnew <- dfnew[,-5]
dfnew <- dfnew[,-13]
dfnew <- dfnew[,-24:-28]
dfnew <- dfnew[,-15:-16]
dim(dfnew)
#table(dfnew$Likelihood.to.recommend,dfnew$Gender)

#dfnewX <- as(dfnew,'transactions')

####################################################################3
#Oursin
Oursin <- dfnew %>%
  filter(str_trim(Partner.Name)=='Oursin Airlines Inc.')
view(Oursin)

library(ggplot2)
GGOursin <- ggplot(Oursin,aes(x=Likelihood.to.recommend)) +
  geom_histogram(binwidth = 3,color='black',fill='white')
GGOursin

###################################################################
#cheapseats
cheapseats <- dfnew %>%
  filter(str_trim(Partner.Name)=='Cheapseats Airlines Inc.')
view(cheapseats)

GC1 <- ggplot(cheapseats,aes(x=Likelihood.to.recommend)) +
  geom_histogram(color='black',fill='black') +
  ggtitle('Histogram of likelihood.to.recommend of Cheapseats Ariline')
GC1

#The airline status bar plot of cheapseats
cheapseats$Airline.Status <- as.factor(cheapseats$Airline.Status)
GC2 <- ggplot(data.frame(cheapseats),aes(x=Airline.Status)) +
  geom_bar()
GC2

# x=age fill=average(like)
cheapseats$Age <- as.numeric(cheapseats$Age)
GC3 <- ggplot(cheapseats,aes(x=Age)) +
  geom_histogram(binwidth = 10,color='black',aes(fill=mean(cheapseats$Likelihood.to.recommend)))
GC3


view(cheapseats)
A1 <- cheapseats %>%
  filter(Age>10 & Age<20) 
meanA1 <- mean(A1$Likelihood.to.recommend)
meanA1
numA1 <- count(A1)
numA1

A2 <- cheapseats %>%
  filter(Age>=20 & Age<30) 
meanA2 <- mean(A2$Likelihood.to.recommend)
meanA2
numA2 <- count(A2)

A3 <- cheapseats %>%
  filter(Age>=30 & Age<40) 
meanA3 <- mean(A3$Likelihood.to.recommend)
meanA3
numA3 <- count(A3)

A4 <- cheapseats %>%
  filter(Age>=40 & Age<50) 
meanA4 <- mean(A4$Likelihood.to.recommend)
meanA4
numA4 <- count(A4)

A5 <- cheapseats %>%
  filter(Age>=50 & Age<60) 
meanA5 <- mean(A5$Likelihood.to.recommend)
meanA5
numA5 <- count(A5)

A6 <- cheapseats %>%
  filter(Age>=60 & Age<70) 
meanA6 <- mean(A6$Likelihood.to.recommend)
meanA6
numA6 <- count(A6)

A7 <- cheapseats %>%
  filter(Age>=70 & Age<80) 
meanA7 <- mean(A7$Likelihood.to.recommend)
meanA7
numA7 <- count(A7)

A8 <- cheapseats %>%
  filter(Age>=80 & Age<90) 
meanA8 <- mean(A8$Likelihood.to.recommend)
meanA8
numA8 <- count(A8)
numA8

ANew <- c(meanA1,meanA2,meanA3,meanA4,meanA5,meanA6,meanA7,meanA8)
ANew <- data.frame(c('10-20','20-30','30-40','40-50','50-60','60-70','70-80','80-90'),ANew)
numA <- data.frame(numA1,numA2,numA3,numA4,numA5,numA6,numA7,numA8)
numA <- t(numA)
ANew <- data.frame(ANew,numA)
colnames(ANew) <- c('Age','Likelihood','num')
view(ANew)

GC3 <- ggplot(ANew,aes(x=Age,y=num)) +
  geom_col(color='black',aes(fill=Likelihood))
GC3

# type of travel
cheapseats$Type.of.Travel <- as.factor(cheapseats$Type.of.Travel)
GC4 <- ggplot(data.frame(cheapseats),aes(x=Type.of.Travel)) +
  geom_bar() +
  ggtitle('Type of travel of the Cheapseats Airline')
GC4

#the likelihood of business travel type of cheapseats airline
CBusiness <- cheapseats %>%
  filter(str_trim(Type.of.Travel)=='Business travel')
GC5 <- ggplot(CBusiness,aes(x=Likelihood.to.recommend)) +
  geom_histogram(color='black',fill='black') +
  ggtitle('Likelihood of business travel of Cheapseats Airline')
GC5

#the likelihood of personal travel type of cheapseats airline
CPersonal <- cheapseats %>%
  filter(str_trim(Type.of.Travel)=='Personal Travel')
GC6 <- ggplot(CPersonal,aes(x=Likelihood.to.recommend)) +
  geom_histogram(color='black',fill='black') +
  ggtitle('Likelihood of personal travel of Cheapseats Airline')
GC6
