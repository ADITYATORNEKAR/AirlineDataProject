# IST 687 Final Project
# SOUTHEAST AIRLINES CUSTOMER SATISFACTION SURVEY ANALYSIS
# Student Names: Jenny Cao, Nisha Rangnani, Rehman Sheikh, Aditya Tornekar, Yifan Wang

# Library required packages
library(arules)
library(arulesViz)
library(RCurl)
library(jsonlite)
library(bitops)
library(tidyverse)
library(tm)
library(wordcloud)
library(Matrix)
library(dplyr)
library(readxl)
library(ggplot2)
library(gghighlight)
library(stringr)


# Student Name: Aditya Tornekar

####################################################Creating Dataframe from JSON##############################
#Use the updated link if required
#dataset <- getURL("http://s3.us-east-1.amazonaws.com/blackboard.learn.xythos.prod/5956621d575cd/8614406?response-content-disposition=inline%3B%20filename%2A%3DUTF-8%27%27fall2019-survey-M02%25281%2529.json&response-content-type=application%2Fjson&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20191122T210821Z&X-Amz-SignedHeaders=host&X-Amz-Expires=21600&X-Amz-Credential=AKIAIL7WQYDOOHAZJGWQ%2F20191122%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Signature=f31190d2764559ba9ef31348732cafe9e2a415fa09da8b134e7464c85c40f3da")
#df <- jsonlite::fromJSON(dataset)
dataset <- fromJSON("fall2019-survey-M02.JSON")
df1 <- dataset
#Created dataframe from the json file
projectData <- df1

#####################################################Data Munging##############################################

 
#Departure.Delay.in.Minutes: Departure delay in minutes was NA only when a flight was cancelled(208 observations), this was changed to 0 as the flight was cancelled.

projectData[which(is.na(projectData$Departure.Delay.in.Minutes), arr.ind = TRUE),22] <- 0

# Arrival.Delay.in.Minutes: 
# Arrival delay had "NA" values for 235 observations, regardless of flight being cancelled or not.
# a) For cancelled flights: This was transformed and set to 0 as the flight was cancelled.

projectData[projectData$Flight.cancelled == 'Yes',23] <- 0 

#projectData[which(is.na(projectData$Arrival.Delay.in.Minutes), arr.ind = TRUE),23] 
#projectData[which(is.na(projectData$Arrival.Delay.in.Minutes), arr.ind = TRUE),23] 


# b)For non cancelled flights: We can use the departure delay time column which is the minimum amount of delay that is possible for arrival delay time.
# Here after the NAs are handled for cancelled flights only NAs present are for non cancelled flights
projectData[which(is.na(projectData$Arrival.Delay.in.Minutes), arr.ind = TRUE),23] <- projectData[which(is.na(projectData$Arrival.Delay.in.Minutes), arr.ind = TRUE),22]


# 3)Flight.time.in.minutes
# This variable had "NA" values for 235 observations.
# a) For cancelled flights(214 rows): This was transformed and set to 0 as the flight was cancelled.

projectData[projectData$Flight.cancelled == 'Yes',25] <- 0 

# b) For non-cancelled flights(21 rows): "NA" values in this scenario were handled by taking average of flight time of other flights which had the same flight distance.

#projectData[which(is.na(projectData$Flight.time.in.minutes), arr.ind = TRUE),25]
#projectData[which(is.na(projectData$Flight.time.in.minutes), arr.ind = TRUE),]

projectData[930,25]   <- 251
projectData[1224,25]  <- 128
projectData[1504,25]  <- 326
projectData[2398,25]  <- 137
projectData[3486,25]  <- 62
projectData[3655,25]  <- 214
projectData[3686,25]  <- 240
projectData[3695,25]  <- 197
projectData[3789,25]  <- 88
projectData[4219,25]  <- 192
projectData[4949,25]  <- 75
projectData[5083,25]  <- 121
projectData[5152,25]  <- 237
projectData[6111,25]  <- 121
projectData[6125,25]  <- 174
projectData[6831,25]  <- 73
projectData[7465,25]  <- 113
projectData[8384,25]  <- 113
projectData[8840,25]  <- 197
projectData[9266,25]  <- 104
projectData[9994,25]  <- 236

# 4)Likelihood.to.recommend
# This variable just had one "NA" value which was converted to a passive score of 7. (1-6 Detractors, 7-8 Passive, 9-10 Promoters)

projectData[which(is.na(projectData$Likelihood.to.recommend), arr.ind = TRUE),27] <- 7

################ Now only NAs present should be in the freeText column ##############################################################


View(projectData) #Original dataset with duplicates
cleanedProjectData <- unique(projectData) #Removing duplicate rows
View(cleanedProjectData)

###################################################### Linear Regression #######################################################################################################

# Initial Linear Model

lm1 <- lm(Likelihood.to.recommend~Airline.Status
          +Age
          +Gender
          +Price.Sensitivity
          +Year.of.First.Flight
          +Flights.Per.Year
          +Loyalty
          +Type.of.Travel
          +Total.Freq.Flyer.Accts
          +Shopping.Amount.at.Airport
          +Eating.and.Drinking.at.Airport
          +Class
          +Partner.Code
          +Partner.Name
          +Scheduled.Departure.Hour
          +Departure.Delay.in.Minutes
          +Arrival.Delay.in.Minutes
          +Flight.cancelled
          +Flight.time.in.minutes
          +Flight.Distance
          +olong
          +olat
          +dlong
          +dlat
          ,data = cleanedProjectData)

# After analysising multiple Linear models below data subset was most impacting Likelihood To Recommend variable.

############################################## Data subset based on inital linear model ############################################################

ModelData <- cleanedProjectData[ (cleanedProjectData$Class == "Eco" | cleanedProjectData$Class == "Business")
                                 & (cleanedProjectData$Type.of.Travel == "Personal Travel" | cleanedProjectData$Type.of.Travel == "Business travel")
                                 & (cleanedProjectData$Partner.Code == "AS" | cleanedProjectData$Partner.Code == "EV" | cleanedProjectData$Partner.Code == "OU")
                                 & (cleanedProjectData$Airline.Status == "Gold" | cleanedProjectData$Airline.Status == "Silver" | cleanedProjectData$Airline.Status == "Blue"),]

############################################### Final Model used for analysis ######################################################################

lm8 <- lm(Likelihood.to.recommend~Airline.Status
          +Age
          +Gender
          +Flights.Per.Year
          +Loyalty
          +Shopping.Amount.at.Airport
          +Eating.and.Drinking.at.Airport
          +Arrival.Delay.in.Minutes
          +olat
          +Class
          +Type.of.Travel
          +Partner.Code 
          ,data = ModelData)

summary(lm8)

###################################################### Visualizations ##################################################################################

# Airline Status: Silver status customers are the ones to boost the Likelihood to recommend,followed by gold,blue,platinum status customers.
# Each tuple of 3 silver status customers boosts the net recommendation score by 4 as compared to gold and blue status customers
##Subset Data visualization
ggairstatus <- ggplot(ModelData,aes(x=Airline.Status,y=Likelihood.to.recommend))+geom_point()+stat_smooth(method = "lm",col = "red")
ggairstatus
ggairstatusbar <- ggplot(ModelData,aes(x=Airline.Status,y=mean(Likelihood.to.recommend))) + stat_summary(fun.y = "mean", geom = "bar")
ggairstatusbar
#Overall Data visualization
ggairstatuso <- ggplot(cleanedProjectData,aes(x=Airline.Status,y=mean(Likelihood.to.recommend))) + stat_summary(fun.y = "mean", geom = "bar")
ggairstatuso


# AGE: As the age increases, a customer tends to give negative recommendation score(every 10 years bring 5% lower recommendation score)
##Subset Data visualization
ggAget <- ggplot(ModelData,aes(x=Age,y=Likelihood.to.recommend)) + geom_point() + stat_smooth(method = "lm", col = "red")
ggAget
#Overall Data visualization
ggAgeo <- ggplot(cleanedProjectData,aes(x=Age,y=Likelihood.to.recommend)) + geom_point() + stat_smooth(method = "lm", col = "red")
ggAgeo


#Gender: Males tend to give better recommendation scores
##Subset Data visualization
gggendert <- ggplot(ModelData,aes(x=Gender,y=mean(Likelihood.to.recommend))) + stat_summary(fun.y = "mean", geom = "bar")
gggendert
#Overall Data visualization
gggendero <- ggplot(cleanedProjectData,aes(x=Gender,y=mean(Likelihood.to.recommend))) + stat_summary(fun.y = "mean", geom = "bar")
gggendero


#Flights per year: As the number of flights taken by a customer in a year increase, 
#for each extra flight customers tend to give 0.1% lower recommendation scores.
##Subset Data visualization
ggFlightsPerYearo <- ggplot(ModelData,aes(x=Flights.Per.Year,y=Likelihood.to.recommend)) + geom_point() + stat_smooth(method = "lm", col = "red")
ggFlightsPerYearo
#Overall Data visualization
ggFlightsPerYeart <- ggplot(cleanedProjectData,aes(x=Flights.Per.Year,y=Likelihood.to.recommend)) + geom_point() + stat_smooth(method = "lm", col = "red")
ggFlightsPerYeart


# Eating & drinking at the airport: Customers who eat & drink at the airport tend to give positive recommendations.
# Each 100$ spent on eating & drinking at the airport translates to increased 4% recommendation score
##Subset Data visualization
ggEatingDrinkingo <- ggplot(ModelData,aes(x=Eating.and.Drinking.at.Airport,y=Likelihood.to.recommend)) + geom_point() + stat_smooth(method = "lm", col = "red")
ggEatingDrinkingo
#Overall Data visualization
ggEatingDrinkingt <- ggplot(cleanedProjectData,aes(x=Eating.and.Drinking.at.Airport,y=Likelihood.to.recommend)) + geom_point() + stat_smooth(method = "lm", col = "red")
ggEatingDrinkingt


# Shopping at the airport: More the amount spent at the airport on shopping better the recommendation score. 
# Each 100$ spent on shopping translates to increased 1% recommendation score
##Subset Data visualization
ggShoppingo <- ggplot(ModelData,aes(x=Shopping.Amount.at.Airport,y=Likelihood.to.recommend)) + geom_point() + stat_smooth(method = "lm", col = "red")
ggShoppingo
#Overall Data visualization
ggShoppingt <- ggplot(cleanedProjectData,aes(x=Shopping.Amount.at.Airport,y=Likelihood.to.recommend)) + geom_point() + stat_smooth(method = "lm", col = "red")
ggShoppingt


#Arrival delay: Every hour of delay during arrival brings down recommendation score by 2.4%
##Subset Data visualization
ggArrivalDelayo <- ggplot(ModelData,aes(x=Arrival.Delay.in.Minutes,y=Likelihood.to.recommend)) + geom_point() + stat_smooth(method = "lm", col = "red")
ggArrivalDelayo
#Overall Data visualization
ggArrivalDelayt <- ggplot(cleanedProjectData,aes(x=Arrival.Delay.in.Minutes,y=Likelihood.to.recommend)) + geom_point() + stat_smooth(method = "lm", col = "red")
ggArrivalDelayt

#Type of travel: Customers traveling for personal work tend to give a negative 2.58 as compared to customers traveling for business reasons. 
#The below graph shows average recommendation scores for each type of travel considered.
##Subset Data visualization
ggTypeoftravelo <- ggplot(ModelData,aes(x=Type.of.Travel,y=Likelihood.to.recommend)) + stat_summary(fun.y = "mean", geom = "bar")
ggTypeoftravelo
#Overall Data visualization
ggTypeoftravelt <- ggplot(cleanedProjectData,aes(x=Type.of.Travel,y=Likelihood.to.recommend)) + stat_summary(fun.y = "mean", geom = "bar")
ggTypeoftravelt

#Loyalty: Overall Loyal customers tend to give better recommendation scores. 
##Subset Data visualization
ggLoyaltyo <- ggplot(cleanedProjectData,aes(x=Loyalty,y=Likelihood.to.recommend)) + geom_point() + stat_smooth(method = "lm", col = "red")
ggLoyaltyo
#Overall Data visualization
ggLoyaltyt <- ggplot(cleanedProjectData,aes(x=Loyalty,y=Likelihood.to.recommend)) + geom_point() + stat_smooth(method = "lm", col = "red")
ggLoyaltyt

#Business Class vs Economic Class
ggClass <- ggplot(ModelData,aes(x=Class,y=Likelihood.to.recommend)) + stat_summary(fun.y = "mean", geom = "bar")
ggClass


############################################# Filtered Airline Dataframes for Linear Regression Analysis #######################

CoolYoung_Airlines_IncData <- cleanedProjectData[ (cleanedProjectData$Partner.Name == "Cool&Young Airlines Inc."),]
EnjoyFlying_Air_ServicesData <- cleanedProjectData[ (cleanedProjectData$Partner.Name == "EnjoyFlying Air Services"),]
FlyHere_AirwaysData <- cleanedProjectData[ (cleanedProjectData$Partner.Name == "FlyHere Airways"),]
FlyToSun_Airlines_IncData <- cleanedProjectData[ (cleanedProjectData$Partner.Name == "FlyToSun Airlines Inc."),]
GoingNorth_Airlines_IncData <- cleanedProjectData[ (cleanedProjectData$Partner.Name == "GoingNorth Airlines Inc."),]
Northwest_Business_Airlines_IncData <- cleanedProjectData[ (cleanedProjectData$Partner.Name == "Northwest Business Airlines Inc."),]
OnlyJets_Airlines_IncData <- cleanedProjectData[ (cleanedProjectData$Partner.Name == "OnlyJets Airlines Inc."),]
Oursin_Airlines_IncData <- cleanedProjectData[ (cleanedProjectData$Partner.Name == "Oursin Airlines Inc."),]
Paul_Smith_Airlines_IncData <- cleanedProjectData[ (cleanedProjectData$Partner.Name == "Paul Smith Airlines Inc."),]
Sigma_Airlines_IncData <- cleanedProjectData[ (cleanedProjectData$Partner.Name == "Sigma Airlines Inc."),]
Southeast_Airlines_CoData <- cleanedProjectData[ (cleanedProjectData$Partner.Name == "Southeast Airlines Co."),]
West_Airways_IncData <- cleanedProjectData[ (cleanedProjectData$Partner.Name == "West Airways Inc."),]


###################################### Top 3 Airlines analysis based on number of customers ####################################

# Cheapseats Airlines Inc (2106 customers)
# Sigma Airlines Inc (1534 customers)
# FlyFast Airways Inc (1149 customers)

##################################### Cheapseats_Airlines_IncData 2106 customers #############################################

Cheapseats_Airlines_IncData <- cleanedProjectData[ (cleanedProjectData$Partner.Name == "Cheapseats Airlines Inc."),]
lm1Cheapseats_Airlines_IncData <- lm(Likelihood.to.recommend~
                                     +Airline.Status
                                     +Age
                                     +Gender
                                     +Price.Sensitivity
                                     +Year.of.First.Flight
                                     +Flights.Per.Year
                                     +Type.of.Travel
                                     +Eating.and.Drinking.at.Airport
                                     +Class
                                     +Scheduled.Departure.Hour
                                     +Departure.Delay.in.Minutes
                                     +Flight.Distance
                                     ,data = Cheapseats_Airlines_IncData)

summary(lm1Cheapseats_Airlines_IncData) 

########################################### Sigma Airlines Inc 1534 Customers ################################################

Sigma_Airlines_IncData <- cleanedProjectData[ (cleanedProjectData$Partner.Name == "Sigma Airlines Inc."),]

lm1Sigma_Airlines_IncData <- lm(Likelihood.to.recommend~
                                +Airline.Status
                                +Age
                                +Gender
                                +Type.of.Travel
                                +Eating.and.Drinking.at.Airport
                                +Scheduled.Departure.Hour
                                +Arrival.Delay.in.Minutes
                                ,data = Sigma_Airlines_IncData)

summary(lm1Sigma_Airlines_IncData)

########################################### FlyFast Airways Inc 1149 Customers ################################################

FlyFast_Airways_IncData <- cleanedProjectData[ (cleanedProjectData$Partner.Name == "FlyFast Airways Inc."),]

lm1FlyFast_Airways_IncData <- lm(Likelihood.to.recommend~
                                 +Airline.Status
                                 +Gender
                                 +Flights.Per.Year
                                 +Type.of.Travel
                                 +Eating.and.Drinking.at.Airport
                                 +Flight.cancelled
                                 +Flight.time.in.minutes
                                 +Flight.Distance
                                 ,data = FlyFast_Airways_IncData)

summary(lm1FlyFast_Airways_IncData)

##############################################################################################################################
# Student Name: Yifan Wang

# Read the Json file from my workind directory
df <- cleanedProjectData
FinalProject <- summary(df)
FinalProject
FinalProject2 <- str(df)
FinalProject2
#import positive and negative directory
pos <- "positive-words.txt"
neg <- "negative-words.txt"
p <- scan(pos,character(0), sep = "\n")
n <- scan(neg,character(0), sep = "\n")
p <- p[-1:-34]
n <- p[-1:-34]

#This model is analyze the entire customers with likelyhood less than 7 to see what caused this issue. And compare
#with the previous sentiment amalysis to determine our insights.
like1 <- df %>% 
  filter(df$Likelihood.to.recommend < 7)
like2 <- like1$freeText[!is.na(like1$freeText)]
word.vec4 <- VectorSource(like2)
words.corpus4 <- Corpus(word.vec4)
words.corpus4 <- tm_map(words.corpus4, stripWhitespace)
words.corpus4 <- tm_map(words.corpus4,content_transformer(tolower))
words.corpus4 <- tm_map(words.corpus4,removePunctuation)
words.corpus4 <- tm_map(words.corpus4,removeNumbers)
words.corpus4 <- tm_map(words.corpus4,removeWords,stopwords("english"))
words.corpus4 <- tm_map(words.corpus4, stemDocument)
Cloud4 <- wordcloud(words.corpus4, scale=c(5,0.5), max.words=50, random.order=FALSE, rot.per=0.35, use.r.layout=FALSE, colors=brewer.pal(8, "Dark2"))
tdm4 <- TermDocumentMatrix(words.corpus4)
m4 <- as.matrix(tdm4)
wordCounts4 <- rowSums(m4)
wordCounts4 <- sort(wordCounts4,decreasing = TRUE)
totalWords4 <- sum(wordCounts4)
words4 <- names(wordCounts4)
matchedP4 <- match(words4,p,nomatch = 0)
mCounts4 <- wordCounts4[which(matchedP4 !=0)]
mwords4 <- names(mCounts4)
npos4 <- sum(mCounts4)
npos4
matchedN4 <- match(words4,n,nomatch = 0)
nCounts4 <- wordCounts4[which(matchedN4 !=0)]
nNeg4 <- sum(nCounts4)
nNeg4
totalWords4 <- length(words4)
Posratios4 <- npos4/totalWords4
Negratios4 <- nNeg4/totalWords4
Posratios4
Negratios4

head(wordCounts4,10)

#create a subset of cheapseats
cheaps <- df %>%
  filter(df$Partner.Name =="Cheapseats Airlines Inc.")
cheaps1 <- cheaps$freeText[!is.na(cheaps$freeText)]
View(cheaps1)
#Create the word clouds for cheapseats airlines inc
word.vec1 <- VectorSource(cheaps1)
words.corpus1 <- Corpus(word.vec1)
words.corpus1 <- tm_map(words.corpus1, stripWhitespace)
words.corpus1 <- tm_map(words.corpus1,content_transformer(tolower))
words.corpus1 <- tm_map(words.corpus1,removePunctuation)
words.corpus1 <- tm_map(words.corpus1,removeNumbers)
words.corpus1 <- tm_map(words.corpus1,removeWords,stopwords("english"))
words.corpus1 <- tm_map(words.corpus1, stemDocument)
Cloud1 <- wordcloud(words.corpus1, scale=c(5,0.5), max.words=50, random.order=FALSE, rot.per=0.35, use.r.layout=FALSE, colors=brewer.pal(8, "Dark2"))
tdm1 <- TermDocumentMatrix(words.corpus1)
m1 <- as.matrix(tdm1)
wordCounts1 <- rowSums(m1)
wordCounts1 <- sort(wordCounts1,decreasing = TRUE)
#Sentiment analysis for cheapseats airlines inc.
totalWords1 <- sum(wordCounts1)
words1 <- names(wordCounts1)
matchedP1 <- match(words1,p,nomatch = 0)
mCounts <- wordCounts1[which(matchedP1 !=0)]
mwords <- names(mCounts)
npos <- sum(mCounts)
npos
matchedN1 <- match(words1,n,nomatch = 0)
nCounts <- wordCounts1[which(matchedN1 !=0)]
nNeg <- sum(nCounts)
nNeg
totalWords1 <- length(words1)
Posratios <- npos/totalWords1
Negratios <- nNeg/totalWords1
Posratios
Negratios
#Given this,we can see that Cheapseats airlines Inc.'s review was made up of about 12% positive and 
#a little less than 12% negative words.

#create a subset of oursin
oursin <- df %>%
  filter(df$Partner.Name =="Oursin Airlines Inc.")
oursin1 <- oursin$freeText[!is.na(oursin$freeText)]
#Create a wordcloud of Oursin airlines inc.
word.vec2 <- VectorSource(oursin1)
words.corpus2 <- Corpus(word.vec2)
words.corpus2 <- tm_map(words.corpus2, stripWhitespace)
words.corpus2 <- tm_map(words.corpus2,content_transformer(tolower))
words.corpus2 <- tm_map(words.corpus2,removePunctuation)
words.corpus2 <- tm_map(words.corpus2,removeNumbers)
words.corpus2 <- tm_map(words.corpus2,removeWords,stopwords("english"))
words.corpus2 <- tm_map(words.corpus2, stemDocument)
Cloud2 <- wordcloud(words.corpus2, scale=c(5,0.5), max.words=50, random.order=FALSE, rot.per=0.35, use.r.layout=FALSE, colors=brewer.pal(8, "Dark2"))
tdm2 <- TermDocumentMatrix(words.corpus2)
m2 <- as.matrix(tdm2)
wordCounts2 <- rowSums(m2)
wordCounts2 <- sort(wordCounts2,decreasing = TRUE)
#Create a sentiment analysis for Oursin Airlines Inc.
totalWords2 <- sum(wordCounts2)
words2 <- names(wordCounts2)
matchedP2 <- match(words2,p,nomatch = 0)
mCounts2 <- wordCounts2[which(matchedP2 !=0)]
mwords2 <- names(mCounts2)
npos2 <- sum(mCounts2)
npos2
matchedN2 <- match(words2,n,nomatch = 0)
nCounts2 <- wordCounts2[which(matchedN2 !=0)]
nNeg2 <- sum(nCounts2)
nNeg2
totalWords2 <- length(words2)
Posratios2 <- npos2/totalWords2
Negratios2 <- nNeg2/totalWords2
Posratios2
Negratios2
#By given this, we can see that the Oursin Airlines Inc. customers' reviews were made up of about 22% positive and 22% negative
#words.

#create a subset of flyfast
flyfast <- df %>%
  filter(df$Partner.Name == "FlyFast Airways Inc.")
flyfast1 <- flyfast$freeText[!is.na(flyfast$freeText)]
##Create the word clouds for FlyFast Airways Inc.
word.vec3 <- VectorSource(flyfast1)
words.corpus3 <- Corpus(word.vec3)
words.corpus3 <- tm_map(words.corpus3, stripWhitespace)
words.corpus3 <- tm_map(words.corpus3,content_transformer(tolower))
words.corpus3 <- tm_map(words.corpus3,removePunctuation)
words.corpus3 <- tm_map(words.corpus3,removeNumbers)
words.corpus3 <- tm_map(words.corpus3,removeWords,stopwords("english"))
words.corpus3 <- tm_map(words.corpus3, stemDocument)
Cloud3 <- wordcloud(words.corpus3, scale=c(5,0.5), max.words=50, random.order=FALSE, rot.per=0.35, use.r.layout=FALSE, colors=brewer.pal(8, "Dark2"))
tdm3 <- TermDocumentMatrix(words.corpus3)
m3 <- as.matrix(tdm3)
wordCounts3 <- rowSums(m3)
wordCounts3 <- sort(wordCounts3,decreasing = TRUE)
#Sentiment analysis for cheapseats airlines inc.
totalWords3 <- sum(wordCounts3)
words3 <- names(wordCounts3)
matchedP3 <- match(words3,p,nomatch = 0)
mCounts3 <- wordCounts3[which(matchedP3 !=0)]
mwords3 <- names(mCounts3)
npos3 <- sum(mCounts3)
npos3
matchedN3 <- match(words3,n,nomatch = 0)
nCounts3 <- wordCounts3[which(matchedN3 !=0)]
nNeg3 <- sum(nCounts3)
nNeg3
totalWords3 <- length(words3)
Posratios3 <- npos/totalWords3
Negratios3 <- nNeg/totalWords3
Posratios3
Negratios3
#By given this, we can see that the FlyFast Airways Inc.. customers' reviews were made up of about 16% positive and a little less than 16% negative
#words.

#support vector machine for CheapSeats
#Contingency table to show the relationship between gender and price sensitivity
CT1 <-table(cheaps$Gender,cheaps$Price.Sensitivity)
CT1 <-prop.table(CT1)
CT1
#Visulization of the contingency table
ggpp <- data.frame(CT1)
colnames(ggpp) <- c("Gender","PriceSensitivity","Proportion")
GGP1 <- ggplot(ggpp,aes(x=ggpp$Gender, y=ggpp$Proportion,group =1))
GGP1 <- GGP1+geom_col()
GGP1 <- GGP1+theme(axis.text.x = element_text(angle = 90,hjust = 1))
GGP1 <- GGP1 + ggtitle("Contingency Table of Price Sensitivity")
GGP1
#Contingency table to show the relationship between gender and airline status
GS1 <-table(cheaps$Gender,cheaps$Airline.Status)
GS1 <- prop.table(GS1)
GS1
#create a subset that contains the attributes for creating the SVM
CheapsX <- cheaps[,3:14]
CheapsX <- select(CheapsX,-c(5,6,9,10,11))
#After I tried serval times, I found I need to use as.character to convert the data type in order to transactions
CheapsX$Airline.Status <- as.character(CheapsX$Airline.Status)
CheapsX$Gender <-as.character(CheapsX$Gender)
CheapsX$Age <- as.character(CheapsX$Age)
CheapsX$Price.Sensitivity <- as.character(CheapsX$Price.Sensitivity)
CheapsX$Loyalty <- CheapsX$Loyalty
CheapsX$Type.of.Travel <- CheapsX$Type.of.Travel
CheapsX$Class <- CheapsX$Class
martix1 <- as(CheapsX,"transactions")
itemFrequency(martix1)
ruleset <- apriori(martix1, 
                   parameter=list(support=0.005,confidence=0.5),
                   appearance = list(default="lhs", rhs=("Gender=Female")))
summary(ruleset)
inspect(ruleset)
plot(ruleset)
goodrules <- ruleset[quality(ruleset)$lift > 1.6]
inspect(goodrules)

#Create the assicoation rules for Oursin Aielines Inc.
#Create the contingency table between gender and price sensitivity
OCT1 <- table(oursin$Gender,oursin$Price.Sensitivity)
OCT2 <- prop.table(OCT1)
OCT2
#Create the contingency table between gender and Airline Status
OGS1 <-table(oursin$Gender,oursin$Airline.Status)
OGS2 <- prop.table(OGS1)
OGS2
#Subset of the attributes that should be concluded in the model
OursinX <- oursin[,3:14]
OursinX <- select(OursinX,-c(5,6,9,10,11))
#Convert data type into transactions
OursinX$Airline.Status <- as.character(OursinX$Airline.Status)
OursinX$Age <- as.character(OursinX$Age)
OursinX$Gender <- as.character(OursinX$Gender)
OursinX$Price.Sensitivity <- as.character(OursinX$Price.Sensitivity)
OursinX$Loyalty <- as.character(OursinX$Loyalty)
OursinX$Type.of.Travel <- as.character(OursinX$Type.of.Travel)
OursinX$Class <- as.character(OursinX$Class)
#Sparse matrix of the Oursin Airline Inc.
matrix2 <- as(OursinX,"transactions")
itemFrequency(matrix2)
ruleset2 <- apriori(matrix2, 
                    parameter=list(support=0.005,confidence=0.5),
                    appearance = list(default="lhs", rhs=("Gender=Female")))
summary(ruleset2)
inspect(ruleset2)
plot(ruleset2)
goodrules2 <- ruleset2[quality(ruleset2)$lift > 1.6]
inspect(goodrules2)

#Create assication rules for FlyFast Airways Inc.
#Create the contingency table between gender and price sensitivity
FFCT1 <- table(flyfast$Gender,flyfast$Price.Sensitivity)
FFCT2 <- prop.table(FFCT1)
FFCT2
#Create the contingency table between gender and Airline Status
FGS1 <-table(flyfast$Gender,flyfast$Airline.Status)
FGS2 <- prop.table(FGS1)
FGS2
#Subset of the attributes that should be concluded in the model
FlyfastX <- flyfast[,3:14]
FlyfastX <- select(FlyfastX,-c(5,6,9,10,11))
#Convert data type into transactions
FlyfastX$Airline.Status <- as.character(FlyfastX$Airline.Status)
FlyfastX$Age <- as.character(FlyfastX$Age)
FlyfastX$Gender <- as.character(FlyfastX$Gender)
FlyfastX$Price.Sensitivity <- as.character(FlyfastX$Price.Sensitivity)
FlyfastX$Loyalty <- as.character(FlyfastX$Loyalty)
FlyfastX$Type.of.Travel <- as.character(FlyfastX$Type.of.Travel)
FlyfastX$Class <- as.character(FlyfastX$Class)
#Sparse matrix of the Oursin Airline Inc.
matrix3 <- as(FlyfastX,"transactions")
itemFrequency(matrix3)
#Creates an assoication rules based on 7 variables
ruleset3 <- apriori(matrix3, 
                    parameter=list(support=0.005,confidence=0.5),
                    appearance = list(default="lhs", rhs=("Gender=Female")))
summary(ruleset3)
inspect(ruleset3)
plot(ruleset3)
goodrules3 <- ruleset3[quality(ruleset3)$lift > 1.4]
inspect(goodrules3)
#the study on female passengers shows that the most popular groups the partners should pay more attentions and provide
# better services to elders because they have lower price sensitivity and most of them purchased the ECO clasas tickets.

#Overall, we recommand that those three partners should provide more professional training to their emplooyee, especially for 
#the cabin crews and luggind services. Once they enhanced these parts, it may improve their reputations and make more profits.

#Morrover, based on the contingencu table, as we can seen, the female passengers are less price sensitity, so we strongly recommand
#these three partners developing more events that will attract more female passengers.For instances, they can provide baby seats, baby foods(adequate water for babies�� bottles on board), and baby bassinet
#services for international travelers. For domestic travelers, they can placed free diapers in the washrooms on board.

##############################################################################################################################
# Student Name: Rehman Sheikh

# Load the data
dataset <- fromJSON("fall2019-survey-M02.JSON")
df <- dataset
# View(df)


# seperating partners into own dataset

northWest <- df[df$Partner.Name == 'Northwest Business Airlines Inc.',]
cheapSeats <- df[df$Partner.Name == 'Cheapseats Airlines Inc.',]
flyFast <- df[df$Partner.Name == 'FlyFast Airways Inc.',]
southEast <- df[df$Partner.Name == 'Southeast Airlines Co.',]
sigmaAir <- df[df$Partner.Name == 'Sigma Airlines Inc.',]
paulSmith <- df[df$Partner.Name == 'Paul Smith Airlines Inc.',]
enjoyFlying <- df[df$Partner.Name == 'EnjoyFlying Air Services',]
oursinAir <- df[df$Partner.Name == 'Oursin Airlines Inc.',]
flyHere <- df[df$Partner.Name == 'FlyHere Airways',]
flyToSun <- df[df$Partner.Name == 'FlyToSun Airlines Inc.',]
coolAndYoung <- df[df$Partner.Name == 'Cool&Young Airlines Inc.',]
goingNorth <- df[df$Partner.Name == 'GoingNorth Airlines Inc.',]
onlyJets <- df[df$Partner.Name == 'OnlyJets Airlines Inc.',]
westAirways <- df[df$Partner.Name == 'West Airways Inc.',]

#mean of the likliehood to reccommend
mean(df$Likelihood.to.recommend, na.rm = TRUE)
# 7.17
mean(northWest$Likelihood.to.recommend, na.rm = TRUE)
# 7.42
mean(cheapSeats$Likelihood.to.recommend, na.rm = TRUE)
# 7.00
mean(flyFast$Likelihood.to.recommend, na.rm = TRUE)
# 6.45
mean(southEast$Likelihood.to.recommend, na.rm = TRUE)
# 7.26
mean(sigmaAir$Likelihood.to.recommend, na.rm = TRUE)
# 7.45
mean(paulSmith$Likelihood.to.recommend, na.rm = TRUE)
# 7.33
mean(enjoyFlying$Likelihood.to.recommend, na.rm = TRUE)
# 7.36
mean(oursinAir$Likelihood.to.recommend, na.rm = TRUE)
# 7.13
mean(flyHere$Likelihood.to.recommend, na.rm = TRUE)
# 7.58
mean(flyToSun$Likelihood.to.recommend, na.rm = TRUE)
# 7.35
mean(coolAndYoung$Likelihood.to.recommend, na.rm = TRUE)
# 7.36
mean(goingNorth$Likelihood.to.recommend, na.rm = TRUE)
# 7.29
mean(onlyJets$Likelihood.to.recommend, na.rm = TRUE)
# 7.31
mean(westAirways$Likelihood.to.recommend, na.rm = TRUE)
# 8

# Table with only likelihood to recommend of all partners
LTR <- data.frame("Partner_Name" = c("northWest","cheapSeats", "flyFast", "southEast", "sigmaAir", "paulSmith", "enjoyFlying", "oursinAir", "flyHere", 
                                     "flyToSun", "coolAndYoung", "goingNorth", "onlyJets", "westAirways"), "NPS" = c(7.42, 7.00, 6.45, 7.26, 
                                                                                                                     7.45, 7.33, 7.36, 7.13, 7.58, 
                                                                                                                     7.35, 7.36, 7.29, 7.31, 8.00
                                     ))

# Create a graph
LTRplot <- ggplot(data = LTR, aes(x=Partner_Name, y=NPS)) + geom_bar(stat = "identity", fill = "#FF6666") + theme(axis.text.x=element_text(angle=75, hjust=1)) + gghighlight(NPS < 7.17)+ geom_hline(yintercept = 7.17, size = 2) +ylim(0,10)
LTRplot <- LTRplot+ ggtitle("NPS Average of Partners VS. Southeast Airlines Average") +theme(plot.title = element_text(hjust = 0.5))

LTRplot

# Linear modeling
lm1<-lm(Likelihood.to.recommend~Age+Airline.Status+Gender+Price.Sensitivity+Year.of.First.Flight+Flights.Per.Year
        +Loyalty+Type.of.Travel+Total.Freq.Flyer.Accts+Shopping.Amount.at.Airport
        +Eating.and.Drinking.at.Airport+Class+Day.of.Month+Flight.date+Origin.State+Origin.City+Destination.City+Destination.State
        +Scheduled.Departure.Hour+Departure.Delay.in.Minutes+Arrival.Delay.in.Minutes+Flight.cancelled+Flight.time.in.minutes+Flight.Distance
        ,data=df)

summary(lm1)

lm2<-lm(Likelihood.to.recommend~Age+Airline.Status+Gender+Price.Sensitivity+Year.of.First.Flight+Flights.Per.Year
        +Loyalty+Type.of.Travel+Total.Freq.Flyer.Accts+Shopping.Amount.at.Airport
        +Eating.and.Drinking.at.Airport+Class
        +Departure.Delay.in.Minutes+Arrival.Delay.in.Minutes+Flight.cancelled
        ,data=flyFast)

summary(lm2)

lm3<-lm(Likelihood.to.recommend~Age+Airline.Status+Gender+Price.Sensitivity+Year.of.First.Flight+Flights.Per.Year
        +Loyalty+Type.of.Travel
        +Eating.and.Drinking.at.Airport+Class
        +Departure.Delay.in.Minutes+Flight.cancelled
        ,data=df)

summary(lm3)

max(dfx$Eating.and.Drinking.at.Airport)

lm4<-lm(Likelihood.to.recommend~Age+Airline.Status+Gender+Price.Sensitivity+Flights.Per.Year
        +Type.of.Travel
        +Eating.and.Drinking.at.Airport+Class
        +Departure.Delay.in.Minutes+Flight.cancelled
        ,data=df)

summary(lm4)

fFlm<-lm(Likelihood.to.recommend~Age+Airline.Status+Gender+Price.Sensitivity+Flights.Per.Year
         +Type.of.Travel
         +Eating.and.Drinking.at.Airport+Class
         +Departure.Delay.in.Minutes+Flight.cancelled
         ,data=flyFast)

# flyFast SVM
# Create flyFast svm data with only significant variables/ variables SouthEast Airlines can control
ffsvm <- flyFast[,c(6,9,12,13,14,22,23,24,27)]

# Group price sensitivity for less breaks. 0 = more sensitive to price, 1 = less sensitive to price
ffsvm$Price.Sensitivity <- replace(ffsvm$Price.Sensitivity, ffsvm$Price.Sensitivity >-1 & ffsvm$Price.Sensitivity <= 2, 1)
ffsvm$Price.Sensitivity <- replace(ffsvm$Price.Sensitivity, ffsvm$Price.Sensitivity >2 & ffsvm$Price.Sensitivity <= 5, 0)

# Grouping Loyalty for less breaks
ffsvm$Loyalty[ffsvm$Loyalty>0] <- 2 
ffsvm$Loyalty[ffsvm$Loyalty<=0] <- 3 
# Reassigning loyalty values to 0,1. 0 = no loyalty, 1 = loyal to company 
ffsvm$Loyalty[ffsvm$Loyalty == 2] <- 1 
ffsvm$Loyalty[ffsvm$Loyalty == 3] <- 0 

# Grouping shopping amount for less breaks. 0 = 0 spent, 1 = 1-25 spent, 2 = 26-50 spent, 3 = 51 - 100 spent, 4 = 101 - 200 spent, 5 = 201 - 300 spent, 6 = 301+ spent
ffsvm$Shopping.Amount.at.Airport <- replace(ffsvm$Shopping.Amount.at.Airport, ffsvm$Shopping.Amount.at.Airport > 1 & ffsvm$Shopping.Amount.at.Airport <= 25, 1)
ffsvm$Shopping.Amount.at.Airport <- replace(ffsvm$Shopping.Amount.at.Airport, ffsvm$Shopping.Amount.at.Airport > 2 & ffsvm$Shopping.Amount.at.Airport <= 50, 2)
ffsvm$Shopping.Amount.at.Airport <- replace(ffsvm$Shopping.Amount.at.Airport, ffsvm$Shopping.Amount.at.Airport > 50 & ffsvm$Shopping.Amount.at.Airport <= 100, 3)
ffsvm$Shopping.Amount.at.Airport <- replace(ffsvm$Shopping.Amount.at.Airport, ffsvm$Shopping.Amount.at.Airport > 100 & ffsvm$Shopping.Amount.at.Airport <= 200, 4)
ffsvm$Shopping.Amount.at.Airport <- replace(ffsvm$Shopping.Amount.at.Airport, ffsvm$Shopping.Amount.at.Airport > 200 & ffsvm$Shopping.Amount.at.Airport <= 300, 5)
ffsvm$Shopping.Amount.at.Airport <- replace(ffsvm$Shopping.Amount.at.Airport, ffsvm$Shopping.Amount.at.Airport > 300 & ffsvm$Shopping.Amount.at.Airport <= 5000, 6)

# Grouping eating amount for less breaks. 0 = 0 spent, 1 = 1-25 spent, 2 = 26-50 spent, 3 = 51 - 100 spent, 4 = 101 - 200 spent, 5 = 201 - 300 spent, 6 = 301+ spent
ffsvm$Eating.and.Drinking.at.Airport <- replace(ffsvm$Eating.and.Drinking.at.Airport, ffsvm$Eating.and.Drinking.at.Airport > 1 & ffsvm$Eating.and.Drinking.at.Airport <= 25, 1)
ffsvm$Eating.and.Drinking.at.Airport <- replace(ffsvm$Eating.and.Drinking.at.Airport, ffsvm$Eating.and.Drinking.at.Airport > 25 & ffsvm$Eating.and.Drinking.at.Airport <= 50, 2)
ffsvm$Eating.and.Drinking.at.Airport <- replace(ffsvm$Eating.and.Drinking.at.Airport, ffsvm$Eating.and.Drinking.at.Airport > 50 & ffsvm$Eating.and.Drinking.at.Airport <= 100, 3)
ffsvm$Eating.and.Drinking.at.Airport <- replace(ffsvm$Eating.and.Drinking.at.Airport, ffsvm$Eating.and.Drinking.at.Airport > 100 & ffsvm$Eating.and.Drinking.at.Airport <= 200, 4)
ffsvm$Eating.and.Drinking.at.Airport <- replace(ffsvm$Eating.and.Drinking.at.Airport, ffsvm$Eating.and.Drinking.at.Airport > 200 & ffsvm$Eating.and.Drinking.at.Airport <= 300, 5)
ffsvm$Eating.and.Drinking.at.Airport <- replace(ffsvm$Eating.and.Drinking.at.Airport, ffsvm$Eating.and.Drinking.at.Airport > 300 & ffsvm$Eating.and.Drinking.at.Airport <= 5000, 6)

# Grouping departure delay for less breaks. 0 = 0 delay, 1 = 1-25 delay, 2 = 26-50 delay, 3 = 51 - 100 delay, 4 = 101 - 200 delay, 5 = 201+ delay
ffsvm$Departure.Delay.in.Minutes <- replace(ffsvm$Departure.Delay.in.Minutes, ffsvm$Departure.Delay.in.Minutes > 1 & ffsvm$Departure.Delay.in.Minutes <= 25, 1)
ffsvm$Departure.Delay.in.Minutes <- replace(ffsvm$Departure.Delay.in.Minutes, ffsvm$Departure.Delay.in.Minutes > 25 & ffsvm$Departure.Delay.in.Minutes <= 50, 2)
ffsvm$Departure.Delay.in.Minutes <- replace(ffsvm$Departure.Delay.in.Minutes, ffsvm$Departure.Delay.in.Minutes > 50 & ffsvm$Departure.Delay.in.Minutes <= 100, 3)
ffsvm$Departure.Delay.in.Minutes <- replace(ffsvm$Departure.Delay.in.Minutes, ffsvm$Departure.Delay.in.Minutes > 100 & ffsvm$Departure.Delay.in.Minutes <= 200, 4)
ffsvm$Departure.Delay.in.Minutes <- replace(ffsvm$Departure.Delay.in.Minutes, ffsvm$Departure.Delay.in.Minutes > 200 & ffsvm$Departure.Delay.in.Minutes <= 2000, 5)

# Grouping arrival delay for less breaks. 0 = 0 delay, 1 = 1-25 delay, 2 = 26-50 delay, 3 = 51 - 100 delay, 4 = 101 - 200 delay, 5 = 201+ delay
ffsvm$Arrival.Delay.in.Minutes <- replace(ffsvm$Arrival.Delay.in.Minutes, ffsvm$Arrival.Delay.in.Minutes > 1 & ffsvm$Arrival.Delay.in.Minutes <= 25, 1)
ffsvm$Arrival.Delay.in.Minutes <- replace(ffsvm$Arrival.Delay.in.Minutes, ffsvm$Arrival.Delay.in.Minutes > 25 & ffsvm$Arrival.Delay.in.Minutes <= 50, 2)
ffsvm$Arrival.Delay.in.Minutes <- replace(ffsvm$Arrival.Delay.in.Minutes, ffsvm$Arrival.Delay.in.Minutes > 50 & ffsvm$Arrival.Delay.in.Minutes <= 100, 3)
ffsvm$Arrival.Delay.in.Minutes <- replace(ffsvm$Arrival.Delay.in.Minutes, ffsvm$Arrival.Delay.in.Minutes > 100 & ffsvm$Arrival.Delay.in.Minutes <= 200, 4)
ffsvm$Arrival.Delay.in.Minutes <- replace(ffsvm$Arrival.Delay.in.Minutes, ffsvm$Arrival.Delay.in.Minutes > 200 & ffsvm$Arrival.Delay.in.Minutes <= 2000, 5)

# Grouping NPS scores for less breaks. 0 = lower NPS, 1= Higher NPS
ffsvm$Likelihood.to.recommend[ffsvm$Likelihood.to.recommend<7] <- 0 
ffsvm$Likelihood.to.recommend[ffsvm$Likelihood.to.recommend>=7] <- 1 

# Converting all numeric columns to a factor for the SVM
ffsvm$Likelihood.to.recommend <- as.factor(ffsvm$Likelihood.to.recommend)
ffsvm$Price.Sensitivity <- as.factor(ffsvm$Price.Sensitivity)
ffsvm$Loyalty <- as.factor(ffsvm$Loyalty)
ffsvm$Shopping.Amount.at.Airport <- as.factor(ffsvm$Shopping.Amount.at.Airport)
ffsvm$Eating.and.Drinking.at.Airport <- as.factor(ffsvm$Eating.and.Drinking.at.Airport)
ffsvm$Departure.Delay.in.Minutes <- as.factor(ffsvm$Departure.Delay.in.Minutes)
ffsvm$Arrival.Delay.in.Minutes <- as.factor(ffsvm$Arrival.Delay.in.Minutes)

# Coerece the data as transactions
ffsvmx1 <- as(ffsvm, "transactions")
itemFrequencyPlot(ffsvmx1)

# Create the ruleset to determine what variables give a higher NPS
ffsvmRuleset1 <- apriori(ffsvmx1,
                         parameter = list(support = 0.005, confidence = 0.5),
                         appearance = list(default = "lhs", rhs=("Likelihood.to.recommend=1")))
inspect(ffsvmRuleset1)
inspectDT(ffsvmRuleset1)

# Create the ruleset to determine what variables give a lower NPS
ffsvmRuleset1Low <- apriori(ffsvmx1,
                            parameter = list(support = 0.005, confidence = 0.5),
                            appearance = list(default = "lhs", rhs=("Likelihood.to.recommend=0")))
inspectDT(ffsvmRuleset1Low)

# oursinAir SVM

# Create oursinAir svm data with only significant variables/ variables SouthEast Airlines can control
oasvm <- oursinAir[,c(6,9,12,13,14,22,23,24,27)]

# Group price sensitivity for less breaks. 0 = more sensitive to price, 1 = less sensitive to price
oasvm$Price.Sensitivity <- replace(oasvm$Price.Sensitivity, oasvm$Price.Sensitivity >-1 & oasvm$Price.Sensitivity <= 2, 1)
oasvm$Price.Sensitivity <- replace(oasvm$Price.Sensitivity, oasvm$Price.Sensitivity >2 & oasvm$Price.Sensitivity <= 5, 0)

# Grouping Loyalty for less breaks
oasvm$Loyalty[oasvm$Loyalty>0] <- 2 
oasvm$Loyalty[oasvm$Loyalty<=0] <- 3 
# Reassigning loyalty values to 0,1. 0 = no loyalty, 1 = loyal to company 
oasvm$Loyalty[oasvm$Loyalty == 2] <- 1 
oasvm$Loyalty[oasvm$Loyalty == 3] <- 0 

# Grouping shopping amount for less breaks. 0 = 0 spent, 1 = 1-25 spent, 2 = 26-50 spent, 3 = 51 - 100 spent, 4 = 101 - 200 spent, 5 = 201 - 300 spent, 6 = 301+ spent
oasvm$Shopping.Amount.at.Airport <- replace(oasvm$Shopping.Amount.at.Airport, oasvm$Shopping.Amount.at.Airport > 1 & oasvm$Shopping.Amount.at.Airport <= 25, 1)
oasvm$Shopping.Amount.at.Airport <- replace(oasvm$Shopping.Amount.at.Airport, oasvm$Shopping.Amount.at.Airport > 2 & oasvm$Shopping.Amount.at.Airport <= 50, 2)
oasvm$Shopping.Amount.at.Airport <- replace(oasvm$Shopping.Amount.at.Airport, oasvm$Shopping.Amount.at.Airport > 50 & oasvm$Shopping.Amount.at.Airport <= 100, 3)
oasvm$Shopping.Amount.at.Airport <- replace(oasvm$Shopping.Amount.at.Airport, oasvm$Shopping.Amount.at.Airport > 100 & oasvm$Shopping.Amount.at.Airport <= 200, 4)
oasvm$Shopping.Amount.at.Airport <- replace(oasvm$Shopping.Amount.at.Airport, oasvm$Shopping.Amount.at.Airport > 200 & oasvm$Shopping.Amount.at.Airport <= 300, 5)
oasvm$Shopping.Amount.at.Airport <- replace(oasvm$Shopping.Amount.at.Airport, oasvm$Shopping.Amount.at.Airport > 300 & oasvm$Shopping.Amount.at.Airport <= 5000, 6)

# Grouping eating amount for less breaks. 0 = 0 spent, 1 = 1-25 spent, 2 = 26-50 spent, 3 = 51 - 100 spent, 4 = 101 - 200 spent, 5 = 201 - 300 spent, 6 = 301+ spent
oasvm$Eating.and.Drinking.at.Airport <- replace(oasvm$Eating.and.Drinking.at.Airport, oasvm$Eating.and.Drinking.at.Airport > 1 & oasvm$Eating.and.Drinking.at.Airport <= 25, 1)
oasvm$Eating.and.Drinking.at.Airport <- replace(oasvm$Eating.and.Drinking.at.Airport, oasvm$Eating.and.Drinking.at.Airport > 25 & oasvm$Eating.and.Drinking.at.Airport <= 50, 2)
oasvm$Eating.and.Drinking.at.Airport <- replace(oasvm$Eating.and.Drinking.at.Airport, oasvm$Eating.and.Drinking.at.Airport > 50 & oasvm$Eating.and.Drinking.at.Airport <= 100, 3)
oasvm$Eating.and.Drinking.at.Airport <- replace(oasvm$Eating.and.Drinking.at.Airport, oasvm$Eating.and.Drinking.at.Airport > 100 & oasvm$Eating.and.Drinking.at.Airport <= 200, 4)
oasvm$Eating.and.Drinking.at.Airport <- replace(oasvm$Eating.and.Drinking.at.Airport, oasvm$Eating.and.Drinking.at.Airport > 200 & oasvm$Eating.and.Drinking.at.Airport <= 300, 5)
oasvm$Eating.and.Drinking.at.Airport <- replace(oasvm$Eating.and.Drinking.at.Airport, oasvm$Eating.and.Drinking.at.Airport > 300 & oasvm$Eating.and.Drinking.at.Airport <= 5000, 6)

# Grouping departure delay for less breaks. 0 = 0 delay, 1 = 1-25 delay, 2 = 26-50 delay, 3 = 51 - 100 delay, 4 = 101 - 200 delay, 5 = 201+ delay
oasvm$Departure.Delay.in.Minutes <- replace(oasvm$Departure.Delay.in.Minutes, oasvm$Departure.Delay.in.Minutes > 1 & oasvm$Departure.Delay.in.Minutes <= 25, 1)
oasvm$Departure.Delay.in.Minutes <- replace(oasvm$Departure.Delay.in.Minutes, oasvm$Departure.Delay.in.Minutes > 25 & oasvm$Departure.Delay.in.Minutes <= 50, 2)
oasvm$Departure.Delay.in.Minutes <- replace(oasvm$Departure.Delay.in.Minutes, oasvm$Departure.Delay.in.Minutes > 50 & oasvm$Departure.Delay.in.Minutes <= 100, 3)
oasvm$Departure.Delay.in.Minutes <- replace(oasvm$Departure.Delay.in.Minutes, oasvm$Departure.Delay.in.Minutes > 100 & oasvm$Departure.Delay.in.Minutes <= 200, 4)
oasvm$Departure.Delay.in.Minutes <- replace(oasvm$Departure.Delay.in.Minutes, oasvm$Departure.Delay.in.Minutes > 200 & oasvm$Departure.Delay.in.Minutes <= 2000, 5)

# Grouping arrival delay for less breaks. 0 = 0 delay, 1 = 1-25 delay, 2 = 26-50 delay, 3 = 51 - 100 delay, 4 = 101 - 200 delay, 5 = 201+ delay
oasvm$Arrival.Delay.in.Minutes <- replace(oasvm$Arrival.Delay.in.Minutes, oasvm$Arrival.Delay.in.Minutes > 1 & oasvm$Arrival.Delay.in.Minutes <= 25, 1)
oasvm$Arrival.Delay.in.Minutes <- replace(oasvm$Arrival.Delay.in.Minutes, oasvm$Arrival.Delay.in.Minutes > 25 & oasvm$Arrival.Delay.in.Minutes <= 50, 2)
oasvm$Arrival.Delay.in.Minutes <- replace(oasvm$Arrival.Delay.in.Minutes, oasvm$Arrival.Delay.in.Minutes > 50 & oasvm$Arrival.Delay.in.Minutes <= 100, 3)
oasvm$Arrival.Delay.in.Minutes <- replace(oasvm$Arrival.Delay.in.Minutes, oasvm$Arrival.Delay.in.Minutes > 100 & oasvm$Arrival.Delay.in.Minutes <= 200, 4)
oasvm$Arrival.Delay.in.Minutes <- replace(oasvm$Arrival.Delay.in.Minutes, oasvm$Arrival.Delay.in.Minutes > 200 & oasvm$Arrival.Delay.in.Minutes <= 2000, 5)

# Grouping NPS scores for less breaks. 0 = lower NPS, 1= Higher NPS
oasvm$Likelihood.to.recommend[oasvm$Likelihood.to.recommend<7] <- 0 
oasvm$Likelihood.to.recommend[oasvm$Likelihood.to.recommend>=7] <- 1

# Converting all numeric columns to a factor for the SVM
oasvm$Likelihood.to.recommend <- as.factor(oasvm$Likelihood.to.recommend)
oasvm$Price.Sensitivity <- as.factor(oasvm$Price.Sensitivity)
oasvm$Loyalty <- as.factor(oasvm$Loyalty)
oasvm$Shopping.Amount.at.Airport <- as.factor(oasvm$Shopping.Amount.at.Airport)
oasvm$Eating.and.Drinking.at.Airport <- as.factor(oasvm$Eating.and.Drinking.at.Airport)
oasvm$Departure.Delay.in.Minutes <- as.factor(oasvm$Departure.Delay.in.Minutes)
oasvm$Arrival.Delay.in.Minutes <- as.factor(oasvm$Arrival.Delay.in.Minutes)

# Coerece the data as transactions
oasvmx <- as(oasvm, "transactions")
itemFrequencyPlot(oasvmx)

# Create the ruleset to determine what variables give a higher NPS
oasvmRuleset <- apriori(oasvmx,
                        parameter = list(support = 0.005, confidence = 0.5),
                        appearance = list(default = "lhs", rhs=("Likelihood.to.recommend=1")))
inspect(oasvmRuleset)
inspectDT(oasvmRuleset)

# Create the ruleset to determine what variables give a lower NPS
oasvmRulesetLow <- apriori(oasvmx,
                           parameter = list(support = 0.005, confidence = 0.5),
                           appearance = list(default = "lhs", rhs=("Likelihood.to.recommend=0")))
inspectDT(oasvmRulesetLow)

# cheapSeat SVM
# Create cheapSeat svm data with only significant variables/ variables SouthEast Airlines can control
cssvm <- cheapSeats[,c(6,9,12,13,14,22,23,24,27)]

# Group price sensitivity for less breaks. 0 = more sensitive to price, 1 = less sensitive to price
cssvm$Price.Sensitivity <- replace(cssvm$Price.Sensitivity, cssvm$Price.Sensitivity >-1 & cssvm$Price.Sensitivity <= 2, 1)
cssvm$Price.Sensitivity <- replace(cssvm$Price.Sensitivity, cssvm$Price.Sensitivity >2 & cssvm$Price.Sensitivity <= 5, 0)

# Grouping Loyalty for less breaks
cssvm$Loyalty[cssvm$Loyalty>0] <- 2 
cssvm$Loyalty[cssvm$Loyalty<=0] <- 3 
# Reassigning loyalty values to 0,1. 0 = no loyalty, 1 = loyal to company 
cssvm$Loyalty[cssvm$Loyalty == 2] <- 1 
cssvm$Loyalty[cssvm$Loyalty == 3] <- 0 

# Grouping shopping amount for less breaks. 0 = 0 spent, 1 = 1-25 spent, 2 = 26-50 spent, 3 = 51 - 100 spent, 4 = 101 - 200 spent, 5 = 201 - 300 spent, 6 = 301+ spent
cssvm$Shopping.Amount.at.Airport <- replace(cssvm$Shopping.Amount.at.Airport, cssvm$Shopping.Amount.at.Airport > 1 & cssvm$Shopping.Amount.at.Airport <= 25, 1)
cssvm$Shopping.Amount.at.Airport <- replace(cssvm$Shopping.Amount.at.Airport, cssvm$Shopping.Amount.at.Airport > 2 & cssvm$Shopping.Amount.at.Airport <= 50, 2)
cssvm$Shopping.Amount.at.Airport <- replace(cssvm$Shopping.Amount.at.Airport, cssvm$Shopping.Amount.at.Airport > 50 & cssvm$Shopping.Amount.at.Airport <= 100, 3)
cssvm$Shopping.Amount.at.Airport <- replace(cssvm$Shopping.Amount.at.Airport, cssvm$Shopping.Amount.at.Airport > 100 & cssvm$Shopping.Amount.at.Airport <= 200, 4)
cssvm$Shopping.Amount.at.Airport <- replace(cssvm$Shopping.Amount.at.Airport, cssvm$Shopping.Amount.at.Airport > 200 & cssvm$Shopping.Amount.at.Airport <= 300, 5)
cssvm$Shopping.Amount.at.Airport <- replace(cssvm$Shopping.Amount.at.Airport, cssvm$Shopping.Amount.at.Airport > 300 & cssvm$Shopping.Amount.at.Airport <= 5000, 6)

# Grouping eating amount for less breaks. 0 = 0 spent, 1 = 1-25 spent, 2 = 26-50 spent, 3 = 51 - 100 spent, 4 = 101 - 200 spent, 5 = 201 - 300 spent, 6 = 301+ spent
cssvm$Eating.and.Drinking.at.Airport <- replace(cssvm$Eating.and.Drinking.at.Airport, cssvm$Eating.and.Drinking.at.Airport > 1 & cssvm$Eating.and.Drinking.at.Airport <= 25, 1)
cssvm$Eating.and.Drinking.at.Airport <- replace(cssvm$Eating.and.Drinking.at.Airport, cssvm$Eating.and.Drinking.at.Airport > 25 & cssvm$Eating.and.Drinking.at.Airport <= 50, 2)
cssvm$Eating.and.Drinking.at.Airport <- replace(cssvm$Eating.and.Drinking.at.Airport, cssvm$Eating.and.Drinking.at.Airport > 50 & cssvm$Eating.and.Drinking.at.Airport <= 100, 3)
cssvm$Eating.and.Drinking.at.Airport <- replace(cssvm$Eating.and.Drinking.at.Airport, cssvm$Eating.and.Drinking.at.Airport > 100 & cssvm$Eating.and.Drinking.at.Airport <= 200, 4)
cssvm$Eating.and.Drinking.at.Airport <- replace(cssvm$Eating.and.Drinking.at.Airport, cssvm$Eating.and.Drinking.at.Airport > 200 & cssvm$Eating.and.Drinking.at.Airport <= 300, 5)
cssvm$Eating.and.Drinking.at.Airport <- replace(cssvm$Eating.and.Drinking.at.Airport, cssvm$Eating.and.Drinking.at.Airport > 300 & cssvm$Eating.and.Drinking.at.Airport <= 5000, 6)

# Grouping departure delay for less breaks. 0 = 0 delay, 1 = 1-25 delay, 2 = 26-50 delay, 3 = 51 - 100 delay, 4 = 101 - 200 delay, 5 = 201+ delay
cssvm$Departure.Delay.in.Minutes <- replace(cssvm$Departure.Delay.in.Minutes, cssvm$Departure.Delay.in.Minutes > 1 & cssvm$Departure.Delay.in.Minutes <= 25, 1)
cssvm$Departure.Delay.in.Minutes <- replace(cssvm$Departure.Delay.in.Minutes, cssvm$Departure.Delay.in.Minutes > 25 & cssvm$Departure.Delay.in.Minutes <= 50, 2)
cssvm$Departure.Delay.in.Minutes <- replace(cssvm$Departure.Delay.in.Minutes, cssvm$Departure.Delay.in.Minutes > 50 & cssvm$Departure.Delay.in.Minutes <= 100, 3)
cssvm$Departure.Delay.in.Minutes <- replace(cssvm$Departure.Delay.in.Minutes, cssvm$Departure.Delay.in.Minutes > 100 & cssvm$Departure.Delay.in.Minutes <= 200, 4)
cssvm$Departure.Delay.in.Minutes <- replace(cssvm$Departure.Delay.in.Minutes, cssvm$Departure.Delay.in.Minutes > 200 & cssvm$Departure.Delay.in.Minutes <= 2000, 5)

# Grouping arrival delay for less breaks. 0 = 0 delay, 1 = 1-25 delay, 2 = 26-50 delay, 3 = 51 - 100 delay, 4 = 101 - 200 delay, 5 = 201+ delay
cssvm$Arrival.Delay.in.Minutes <- replace(cssvm$Arrival.Delay.in.Minutes, cssvm$Arrival.Delay.in.Minutes > 1 & cssvm$Arrival.Delay.in.Minutes <= 25, 1)
cssvm$Arrival.Delay.in.Minutes <- replace(cssvm$Arrival.Delay.in.Minutes, cssvm$Arrival.Delay.in.Minutes > 25 & cssvm$Arrival.Delay.in.Minutes <= 50, 2)
cssvm$Arrival.Delay.in.Minutes <- replace(cssvm$Arrival.Delay.in.Minutes, cssvm$Arrival.Delay.in.Minutes > 50 & cssvm$Arrival.Delay.in.Minutes <= 100, 3)
cssvm$Arrival.Delay.in.Minutes <- replace(cssvm$Arrival.Delay.in.Minutes, cssvm$Arrival.Delay.in.Minutes > 100 & cssvm$Arrival.Delay.in.Minutes <= 200, 4)
cssvm$Arrival.Delay.in.Minutes <- replace(cssvm$Arrival.Delay.in.Minutes, cssvm$Arrival.Delay.in.Minutes > 200 & cssvm$Arrival.Delay.in.Minutes <= 2000, 5)

# Grouping NPS scores for less breaks. 0 = lower NPS, 1= Higher NPS
cssvm$Likelihood.to.recommend[cssvm$Likelihood.to.recommend<7] <- 0 
cssvm$Likelihood.to.recommend[cssvm$Likelihood.to.recommend>=7] <- 1 

# Converting all numeric columns to a factor for the SVM
cssvm$Likelihood.to.recommend <- as.factor(cssvm$Likelihood.to.recommend)
cssvm$Price.Sensitivity <- as.factor(cssvm$Price.Sensitivity)
cssvm$Loyalty <- as.factor(cssvm$Loyalty)
cssvm$Shopping.Amount.at.Airport <- as.factor(cssvm$Shopping.Amount.at.Airport)
cssvm$Eating.and.Drinking.at.Airport <- as.factor(cssvm$Eating.and.Drinking.at.Airport)
cssvm$Departure.Delay.in.Minutes <- as.factor(cssvm$Departure.Delay.in.Minutes)
cssvm$Arrival.Delay.in.Minutes <- as.factor(cssvm$Arrival.Delay.in.Minutes)

# Coerece the data as transactions
cssvmx <- as(cssvm, "transactions")
itemFrequencyPlot(cssvmx)

# Create the ruleset to determine what variables give a higher NPS
cssvmRuleset <- apriori(cssvmx,
                        parameter = list(support = 0.005, confidence = 0.5),
                        appearance = list(default = "lhs", rhs=("Likelihood.to.recommend=1")))
inspect(cssvmRuleset)
inspectDT(cssvmRuleset)


# Create the ruleset to determine what variables give a lower NPS
cssvmRulesetLow <- apriori(cssvmx,
                           parameter = list(support = 0.005, confidence = 0.5),
                           appearance = list(default = "lhs", rhs=("Likelihood.to.recommend=0")))
inspectDT(cssvmRulesetLow)

# Coerece the data as transactions - cheapSeats, flyFast, oursinAir combined
low3 <- rbind(cssvm, oasvm, ffsvm)
low3svm <- as(low3, "transactions")
itemFrequencyPlot(low3svm)

# Create the ruleset to determine what variables give a higher NPS
low3Ruleset <- apriori(low3svm,
                       parameter = list(support = 0.005, confidence = 0.5),
                       appearance = list(default = "lhs", rhs=("Likelihood.to.recommend=1")))
inspect(low3Ruleset)
inspectDT(low3Ruleset)


# Create the ruleset to determine what variables give a lower NPS
low3RulesetLow <- apriori(low3svm,
                          parameter = list(support = 0.005, confidence = 0.5),
                          appearance = list(default = "lhs", rhs=("Likelihood.to.recommend=0")))
inspectDT(low3RulesetLow)

##############################################################################################################################
# Student Name: Jenny Cao and Nisha Rangnani
dfnew <- cleanedProjectData

#Oursin
Oursin <- dfnew %>%
  filter(str_trim(Partner.Name)=='Oursin Airlines Inc.')
view(Oursin)

GGOursin <- ggplot(Oursin,aes(x=Likelihood.to.recommend)) +
  geom_histogram(binwidth = 3,color='black',fill='white')
GGOursin

###################################################################
#cheapseats
dfnew <- cleanedProjectData
cheapseats <- dfnew %>%
  filter(str_trim(Partner.Name)=='Cheapseats Airlines Inc.')
view(cheapseats)

GC1 <- ggplot(cheapseats,aes(x=Likelihood.to.recommend)) +
  geom_histogram(color='black',fill='black') +
  ggtitle('Histogram of likelihood.to.recommend of Cheapseats Ariline')
GC1

#The airline status bar plot of cheapseats
cheapseats$Airline.Status <- as.factor(cheapseats$Airline.Status)
GC2 <- ggplot(data.frame(cheapseats),aes(x=Airline.Status)) +
  geom_bar()
GC2

# x=age fill=average(like)

view(cheapseats)
A1 <- cheapseats %>%
  filter(Age>10 & Age<20) 
meanA1 <- mean(A1$Likelihood.to.recommend)
meanA1
numA1 <- count(A1)
numA1

A2 <- cheapseats %>%
  filter(Age>=20 & Age<30) 
meanA2 <- mean(A2$Likelihood.to.recommend)
meanA2
numA2 <- count(A2)

A3 <- cheapseats %>%
  filter(Age>=30 & Age<40) 
meanA3 <- mean(A3$Likelihood.to.recommend)
meanA3
numA3 <- count(A3)

A4 <- cheapseats %>%
  filter(Age>=40 & Age<50) 
meanA4 <- mean(A4$Likelihood.to.recommend)
meanA4
numA4 <- count(A4)

A5 <- cheapseats %>%
  filter(Age>=50 & Age<60) 
meanA5 <- mean(A5$Likelihood.to.recommend)
meanA5
numA5 <- count(A5)

A6 <- cheapseats %>%
  filter(Age>=60 & Age<70) 
meanA6 <- mean(A6$Likelihood.to.recommend)
meanA6
numA6 <- count(A6)

A7 <- cheapseats %>%
  filter(Age>=70 & Age<80) 
meanA7 <- mean(A7$Likelihood.to.recommend)
meanA7
numA7 <- count(A7)

A8 <- cheapseats %>%
  filter(Age>=80 & Age<90) 
meanA8 <- mean(A8$Likelihood.to.recommend)
meanA8
numA8 <- count(A8)
numA8

ANew <- c(meanA1,meanA2,meanA3,meanA4,meanA5,meanA6,meanA7,meanA8)
ANew <- data.frame(c('10-20','20-30','30-40','40-50','50-60','60-70','70-80','80-90'),ANew)
numA <- data.frame(numA1,numA2,numA3,numA4,numA5,numA6,numA7,numA8)
numA <- t(numA)
ANew <- data.frame(ANew,numA)
colnames(ANew) <- c('Age','Likelihood','num')
view(ANew)

GC3 <- ggplot(ANew,aes(x=Age,y=num)) +
  geom_col(color='black',aes(fill=Likelihood))
GC3

# type of travel
cheapseats$Type.of.Travel <- as.factor(cheapseats$Type.of.Travel)
GC4 <- ggplot(data.frame(cheapseats),aes(x=Type.of.Travel)) +
  geom_bar() +
  ggtitle('Type of travel of the Cheapseats Airline')
GC4

#the likelihood of business travel type of cheapseats airline
CBusiness <- cheapseats %>%
  filter(str_trim(Type.of.Travel)=='Business travel')
GC5 <- ggplot(CBusiness,aes(x=Likelihood.to.recommend)) +
  geom_histogram(color='black',fill='black') +
  ggtitle('Likelihood of business travel of Cheapseats Airline')
GC5

#the likelihood of personal travel type of cheapseats airline
CPersonal <- cheapseats %>%
  filter(str_trim(Type.of.Travel)=='Personal Travel')
GC6 <- ggplot(CPersonal,aes(x=Likelihood.to.recommend)) +
  geom_histogram(color='black',fill='black') +
  ggtitle('Likelihood of personal travel of Cheapseats Airline')
GC6


